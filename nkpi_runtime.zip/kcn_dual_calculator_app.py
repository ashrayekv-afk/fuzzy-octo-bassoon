"""Streamlit entry point. Run: streamlit run kcn_dual_calculator_app.py"""
from pathlib import Path
import streamlit as st
from nkpi.component import render_workspace
from nkpi.recovery_ui import render_recovery
from nkpi.service import calculate, configuration

st.set_page_config(page_title="NKPI | Bilateral calculator", page_icon="◉", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""<style>
.block-container{padding:3.75rem .5rem 1rem!important;max-width:1120px!important;}
[data-testid="stAppViewContainer"]{background:#F7F6FA;}
[data-testid="stHeader"]{background:transparent;}
iframe{border:0;} footer{visibility:hidden;}
</style>""", unsafe_allow_html=True)
try:
    config = configuration()
except Exception:
    st.error("The model artifacts did not pass verification. Restore the complete models and research folders from this release.")
    st.stop()
interface = st.radio(
    "Interface", ["Full interface", "Basic calculator (loading recovery)"],
    horizontal=True, key="nkpi_interface_selection",
    help="Switching interfaces clears the current case. The basic calculator uses the same frozen models without the custom browser component.",
)
previous = st.session_state.get("nkpi_previous_interface")
if previous != interface:
    for key in list(st.session_state):
        if key.startswith("nkpi_recovery_") or key in ("nkpi_response", "nkpi_last_event"):
            del st.session_state[key]
    st.session_state["nkpi_previous_interface"] = interface
if interface == "Basic calculator (loading recovery)":
    render_recovery(config)
    st.stop()
st.caption("Build 9.2.1 · Fluid corneal replay · Working October 27 extractor unchanged. Continuous surface animation and local GIF/video export below the original 3D viewer.")
try:
    event = render_workspace(config=config, response=st.session_state.get("nkpi_response"), key="nkpi_v921_fluid", default=None)
except (FileNotFoundError, OSError):
    st.error("The custom interface files could not be served. Select Basic calculator above, or restore the matching launcher and runtime ZIP.")
    st.stop()
if isinstance(event, dict) and event.get("id") != st.session_state.get("nkpi_last_event"):
    event_id = event.get("id")
    if not isinstance(event_id, str) or not 1 <= len(event_id) <= 100:
        st.stop()
    st.session_state["nkpi_last_event"] = event_id
    if event.get("action") == "clear":
        st.session_state.pop("nkpi_response", None)
        st.rerun()
    elif event.get("action") == "assess":
        try:
            response = {"id": event_id, "result": calculate(event.get("payload"))}
        except (ValueError, TypeError, KeyError):
            response = {"id": event_id, "error": "Input verification failed. Check the eye, values, scan order and source confirmation; no score was substituted."}
        except Exception:
            response = {"id": event_id, "error": "Calculation did not complete. Restore the complete release package; no fallback score is used."}
        st.session_state["nkpi_response"] = response
        st.rerun()
