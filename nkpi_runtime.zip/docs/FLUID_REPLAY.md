# NKPI 9.2.1 — fluid corneal replay

## Scope and source

Base: `NKPI_Oct27_Extractor_Replay_GitHub.zip` (9.2.0), SHA-256
`f507ef3d0a74ffae8e73fee294d7053118b79f2d1252e75dbf47d91efd586b41`.

This is a replay-only update. All 34 extractor files, all three OCR delivery adapters,
13 original corneal-viewer files and three frozen model artifacts are byte-identical
to that base. NKPI service code differs only in its UI version. The component name,
application banner and delivery-build identifier change to identify the new release.
No new OCR work, reading rules, training, risk formula or report-upload pathway is added.

## Visible changes

- Continuous geometry, not two stills or a 13-image cache. Endpoint meshes are prepared
  once; each animation frame interpolates supported surface coordinates. The camera
  is fixed and both eyes use the same physical scale within the replay.
- `Prepare & play` starts playback after the user requests it. Play/Pause, slider,
  baseline and latest buttons are above the eyes. Pause/resume and display changes
  preserve position. Reduced-motion preferences prevent automatic play.
- Tight cornea close-up, no large white reference-globe block. The central 94% of the
  common source radius is displayed to trim the outer completion boundary. The main
  natural-eye viewer above is unchanged and remains available for the broader view.
- Dashed baseline meridian guide. Only shared source-supported locations move.
  Unsupported regions are held at baseline and colored gray; no tissue displacement
  or numerical reading is invented there. Source-support overlay remains optional.
- Actual display scale x1 is the default. x3, x5 and x10 multiply only the supported
  difference from baseline. Magnification is labeled in the interface and every
  exported frame. It does not alter scalar inputs, colors, measured rates or NKPI.
- Source-compatible thickness and curvature colors use fixed endpoint scales. Maps
  without compatible definitions or direct support remain unavailable/gray.

## Smooth video, rather than recording slow screen updates

Where canvas WebP encoding is available, the video exporter renders and encodes every
frame before delivering a VP8/WebM movie with explicit 30 fps timestamps. It uses the
browser's WebP encoder for VP8 keyframes and a local EBML/WebM writer. It does not rely
on the screen maintaining 30 fps while recording. Movies are silent, carry fixed
interpretation labels, and open in an on-page video player after export. No microphone,
camera or server upload is used. Video memory consists of compressed frames, not a
retained array of all raw image frames. This method produces larger movies than
inter-frame compression; clips are limited to the provided durations.

Browsers without suitable WebP encoding fall back to their MediaRecorder, where frame
rate depends on actual rendering. The interface marks that fallback. GIF uses 20 fps
with frames encoded incrementally and an adaptive palette. Still export is also local.

On-screen motion follows requestAnimationFrame timestamps, without quantizing time to
13 poses. Hardware WebGL is preferred; software rasterizers use the lighter Canvas
geometry renderer. The display reports measured local fps. This is not a guarantee of
60 fps on clinic hardware. Exported frame-by-frame video avoids this real-time limit.

## Interpretation limits

Two examinations support two observed endpoints, not a measured movie of what happened
between them. Intermediate shapes are illustrative interpolation, not additional scans,
verified tissue motion, forecasts, proof of progression or evidence of acceleration.
The reconstruction can flatten as well as steepen: the animation does not force disease
worsening. Zero supported geometric change remains stationary.

Coordinates and reference surfaces must be compatible; a mismatched eye or grid does
not acquire fabricated motion. Display-coordinate alignment is not anatomical
registration. Image-derived geometry remains approximate; an inner boundary can be
thickness-derived. Changes to reference spheres may affect the comparison. This is not
an anatomical-validation or surgical-planning tool. Magnified shapes are not actual
anatomy. Scalar C does not locate or supply regional thinning.

Rates use verified endpoint values and observed elapsed days; they are not forecasts.
Review scan quality, repeatability, contact lens conditions and treatment/CXL history
before interpretation. Existing source-verification gates remain mandatory. Clinical
numbers in an export may still be sensitive even without names or exact dates.

## Engineering verification performed

- 55 Python tests passed, including preserved-source and compiled delivery/CSP checks.
- 26 JavaScript test scripts passed. New tests check continuous fractions, endpoint
  coordinates, zero-change behavior, support gating, magnification, equal physical
  scale, immutable sources, GIF and deterministic WebM encoding.
- 24 browser checks passed with synthetic paired corneal surfaces. GPU shaders were
  compiled/executed through Chromium's virtual graphics backend. Canvas fallback,
  playback, pause/resume, controls, map switches, source preservation, cancellations,
  changed-case cleanup, mobile layout and reduced-motion settings were exercised.
- 21 sampled corneal-region renders produced 21 distinct hashes, excluding all text
  and timeline regions; the animation was not just changing a status label.
- Browser-produced four-second WebM independently decoded as VP8, 1100 x 720,
  exactly 30 fps, 120 frames and 4.000-second duration. The corneal-only crop had 103
  distinct decoded frames; endpoint dwells account for repeated frames.
- Browser-produced GIF independently decoded as 880 x 576, 80 frames, 4,000 ms total
  duration and 69 distinct corneal-region frames. It is a 20 fps animation, not a
  13-pose slideshow. Video preview and both export cancellations passed.
- The original extractor and delivery adapters were not rewritten or freshly benchmarked
  for real-report extraction. Their byte preservation is separately verified.

Browser checks used set_content and synthetic data, not a live Streamlit server or a
patient report. Streamlit/Community Cloud deployment, the clinic network, real patient
field accuracy and native-device anatomical fidelity have not been validated here.
Virtual graphics timing is not a clinic performance benchmark. Software tests are not
clinical validation. Earlier source-release verification files are historical records.

## Reproduce

Run `python tools/build_delivery.py`, `python -m pytest -q`, all `tests/*.cjs` with Node,
and `python tools/check_fluid_replay_browser.py` with Playwright and Chromium. Browser
tests require functioning virtual graphics for the explicit WebGL check; the production
app does not require Xvfb or additional Python packages. `tools/verify_package.py` checks
the runtime manifest. Browser evidence is in `docs/fluid_checks/`.

Technical references: MDN requestAnimationFrame and HTMLCanvasElement.toBlob;
WebM Project container guidelines. No new external code dependency is introduced.
