# Verification — NKPI 9.2.0 October 27 extractor + replay

## Source and scope
The source for extraction is `NKPI_v910_GitHub_Upload.zip`, archived October 27,
2026. This restores the original field-reading code, not the November 3 parallel
extraction/alignment upgrade. The numerical reading files in the October 27,
October 30 and November 2 archives were compared; the core scalar reader was the
same. Changing the version number alone would not repair its loading route.

34 original extractor/source/vendor/model files are byte-for-byte identical to
the October 27 archive. All 13 original corneal-rendering files and all three
frozen model artifacts are unchanged. Three replay files are unchanged; the
fourth differs only in its displayed version badge and version metadata. Detailed
hashes and source archive hash are in `docs/SOURCE_PROVENANCE.json`.

## What is different
A transport-only adapter supplies the original Tesseract 7 API with an embedded
worker/core and embedded English traineddata, instead of fetching them through
separate component paths. Primary SIMD feature probes/priority and portable
secondary-engine selection match the archived implementation. The archived
reading/crop/parser/consensus/eye-association functions are not rewritten.

The full importer is delivered inside the main component and mounted with srcdoc.
Compiled location references use an explicit same-origin base URL. Source/parent
checks, source confirmation and extraction safeguards remain. CORS/XSRF are not
disabled. Required inline script CSP hashes are regenerated and checked.

A guard stops automatic import when OCR cannot initialize. No-source results are
not called a successful extraction. Startup text now distinguishes browser setup
from a patient visit. Optional manual source association is in technical help.
No OCR calls were added for the replay, and no report images are uploaded by the
new code. Optional PDF/TIFF decoder dependencies are unchanged.

## Checks completed for this build
- **55 Python tests passed.** This includes model/input/audit checks and new
  original-source, inline-document, CSP, embedded-asset and version-only checks.
- **24 JavaScript test scripts passed.** Original extraction consistency,
  second-reader, laterality and viewer tests are retained. The app reset harness
  was updated to observe the new importer remount function.
- **14 delivery/browser checks passed.** Both actual primary OCR workers and the
  original secondary model started and read synthetic digits. A synthetic ZIP
  containing four report-layout JPEGs was then processed through the original
  archive-to-review pipeline. Both printed eyes were identified correctly and
  **all 12 fields matched**, with distinct OD and OS values. This exercised
  179 actual OCR calls, not mocked recognition outputs.
- No HTTP requests were observed by the browser request listener during that
  packaged importer/engine/report test. Model data are supplied through in-memory
  data URLs and workers through blob URLs, not separate HTTP OCR downloads.
- An injected worker-unavailable failure stopped automatic extraction explicitly.
- **13 replay browser checks passed.** Both-eye endpoints, smooth illustrative
  frames, profile/thickness views, source preservation, cancellation, insufficient
  spatial data, and original software-renderer fallback were exercised.
- Actual GIF and WebM video files exported. All 13 GIF frames decoded successfully
  at 1100 x 660. ffprobe identified the WebM as VP9, 1100 x 660.
- **100 synthetic eye outputs (50 bilateral payloads)** exactly matched the
  October 27 release, including returned explanations/audits. UI version was
  excluded; PDF generation was disabled. RNG seed 92027.

Synthetic printed fixture values:

| Eye | A | B | C | Kmax | BAD-D | ARTmax |
|---|---:|---:|---:|---:|---:|---:|
| OD | 7.20 | 5.80 | 480 | 52.0 | 5.20 | 260 |
| OS | 7.10 | 5.70 | 470 | 53.0 | 6.20 | 235 |

These deliberately clean synthetic panels establish execution and regression
behavior. They do **not** establish accuracy across real Pentacam layouts,
report-image quality, or the pictured patient's ZIP. No clinic speed claim is made.

## Environment and untested boundaries
Tests ran on Python 3.13, Node 22 and Chromium. Deployment target remains Python
3.12 with the original dependency pins. Installing Streamlit was attempted but
the package server could not be resolved in this environment. Managed Chromium
blocked URL navigation even to localhost. The browser checks therefore used
`set_content` with the production component and its actual nested srcdoc importer,
an explicit test base, and an opaque test origin; production inline-script CSP
hashes stayed enforced. Real same-origin Streamlit parent-message delivery,
Community Cloud asset serving, and the clinic network/browser were not tested.
Original component-bridge interactions are also covered by the existing unit
harness, not a live Streamlit session. No patient scans were used. These checks
are not clinical validation, native-device geometric validation, a guarantee of
network compatibility, or proof of improved extraction accuracy.

The replay remains illustrative: observed endpoints are reconstructed from
available spatial data, and smooth intermediate frames are labeled interpolation,
not measured visits or forecasts. No spatial data means no invented cornea.

## Reproduction
Inside an extracted runtime:

    python tools/build_delivery.py
    python -m pytest -q
    # Run every tests/*.cjs file with Node.js.
    python tools/check_delivery_browser.py
    python tools/check_replay_browser.py
    python tools/verify_package.py

Browser checks need Playwright and Chromium; they are not production dependencies.
Synthetic fixture data are in tests/fixtures/synthetic_pair.zip. Machine-readable
check results are in docs/release_checks/. Archived source is not duplicated.
