# Verification — 9.1.5.4 replay / extractor rollback

Engineering verification on synthetic fixtures. These checks do not establish
clinical extraction accuracy, scan repeatability, anatomical validity or a speedup.

## Preserved baseline

Source: `NKPI_v9152_OCR_Repair_GitHub.zip`, SHA-256
`98ca30e3d54a0c4c1d6e6301ea6c32794e0a373227d92663f4609c0ae86fcfc2`.

All **36 extractor files**, **13 original cornea files** and **3 frozen model
artifacts** match that source byte-for-byte. See `REPLAY_PRESERVED_HASHES.json`.
The 9.1.5.3 extraction upgrade modules are absent. Dependencies are unchanged.

## Passed checks

- **52 Python tests**, including restored-file hashes, absence of the extraction
  experiment, inclusion order, no new network/persistent-storage code in the replay,
  and reuse of the existing source-binding gate.
- **25 JavaScript test scripts**, including 13 replay assertions (valid intervals,
  raw radius direction, missing values, eye/visit separation, compatible grids,
  endpoint identity, source immutability, no accepted intermediate readings, no
  extrapolation), plus independent LZW decoding and GIF cancellation checks.
- **13 browser checks** for the real original Canvas renderer, paired endpoint
  playback, thirteen-frame smooth geometry, source preservation, profile/thickness
  modes, GIF export, actual WebM/VP9 video export, missing-source refusal, software
  fallback, cancellation during new-case preparation and absence of exceptions.
- **8 further browser checks** using synthetic report-image-style elevation/maps:
  paired preparation, smooth geometry, shared-scale colors, preserved source data,
  canceled GIF, actual regional-controller source binding, dirty-source invalidation,
  new-patient clear and no browser exceptions (some grouped into a single check).
- **100 bilateral payloads / 200 eyes** produced exactly the same calculation,
  prediction, evidence and audit objects as the source release. UI version excluded;
  PDF generation disabled. 100 baseline and 100 longitudinal eyes, seed 9154.
- Exported GIF was independently opened and every frame decoded with Pillow: 13
  frames, 1100 × 660 pixels, approximately six seconds, with changing eye pixels
  inside the canvas, not merely changing labels. Encoder test pixels matched an
  independent GIF decoder. Video contained a 1100 × 660 VP9 stream.

The new browser module reuses a separate instance of the unchanged integrated-eye
renderer. Its private display-view objects receive the endpoint or interpolated
model; the main viewer, original report arrays and scalar inputs are never changed.

## Test method and limitations

Python 3.13, Node 22, headless Chromium 144 and Playwright were used. Browser URL
navigation is blocked in this environment, so actual source scripts/styles were
loaded through set_content. No replay image, geometry, interpolation, GIF encoder
or video recorder was mocked. WebGL was unavailable; the actual Canvas fallback
was exercised. The retained hardware-rendering path was not separately rendered.
Native-coordinate and report-image-style fixtures were explicitly synthetic; no
patient reports were used. The browser tests are not a Streamlit server/Cloud test.

No live repository was modified and no app deployed. No clinic Windows browser,
network, fresh real Pentacam OCR, patient report-to-score run, complete multi-visit
history or PDF export was validated here. The earlier extractor was restored based
on the user's report that it worked, not on a new clinical-field-accuracy benchmark.
A browser/network worker failure can still affect the restored reader. The existing
OCR self-check and source-verification requirements are unchanged.

Intermediate frames are illustrative and unmeasured. Grid compatibility does not
establish anatomical registration. Image-based reference changes may affect apparent
motion. Rates are descriptive, not predicted future rates, repeatability thresholds,
statistical confidence bands, treatment advice or evidence of acceleration.

## Reproduce

After extracting the internal runtime locally:

    python -m pytest -q
    for f in tests/*.cjs; do node "$f"; done
    python tools/verify_package.py
    python tools/check_replay_browser.py

The browser check additionally requires Playwright and Chromium (development-only;
not added to app requirements). Set CHROMIUM to an executable path when needed.
It generates synthetic fixtures and output in a temporary directory. Its reports
and example exports are not a real patient case.

Machine-readable results are in `docs/replay_checks/`. Runtime/outer archive hashes
and the hash-checked launcher installation check are appended to the separately
delivered verification file after final packaging.
