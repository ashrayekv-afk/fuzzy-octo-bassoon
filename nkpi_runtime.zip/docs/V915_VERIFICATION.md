# 9.1.5 verification record

## Engineering checks actually run

- All 41 Python tests passed.
- All pre-existing JavaScript suites passed (214 PASS-labeled groups in their logs,
  including the 13 continuous-review checks); 8 new natural-renderer checks passed.
- 75 UI tests passed in Chromium with WebGL/SwiftShader and explicitly forced Canvas.
  Included graphics context loss and restoration, all map fields, data immutability,
  shared scale, phone layout, PNG generation, source modal, and hidden-panel resizing.
- 8 full-component smoke checks passed using actual HTML/script order, backend config,
  a manual-entry payload and live Python calculator results with a simulated message bridge.
- 12 bilateral payloads (24 eyes) across both modes, three ages and two measurement
  profiles matched 9.1.4 exactly after removing only ui_version. Four PDF outputs per
  version had valid PDF header/trailer and nonempty content; no PDF visual audit claimed.
- Core reconstruction and source-processing modules, all extractor files and model
  files match the prior release byte-for-byte. Display material/lighting/camera handling
  cannot alter C, supplied coordinates, original minimum or the score.

## Browser circumstances

The test browser is local Chromium running with an X virtual framebuffer for software
WebGL. Scripts and styles were injected from the actual distribution, avoiding external
network dependencies. One harness used native-schema synthetic fields with deliberate
missing patches and separate confirmed C inputs; these test the audit rather than claim
that mismatching C and maps describe a real patient. No sample patient data are shipped.

## Packaging checks

`FILE_MANIFEST.json` inventories distributed sources with their SHA-256 values. The
outer launcher independently checks the exact inner ZIP hash before safe extraction.
Launcher extraction/reuse, mismatch and missing-file behavior are tested for the final
archive. See the main README for the five-file upload layout.

## Not tested / not established

No fresh end-to-end OCR on a new report, no direct reconstruction validation against a
Pentacam coordinate export, no test of clinical decision accuracy or repeatability.
No fresh live Streamlit server or cloud deployment; streamlit was not installed locally
and package downloads failed in this environment. Full component smoke testing is not
a substitute for live deployment. Backend tests used local Python 3.13; target 3.12
and the prior dependency pins remain unchanged. First-use verification against the
original source report is still required.
