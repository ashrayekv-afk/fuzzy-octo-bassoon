# Verification — 9.1.5.2-ocr-repair

These are engineering checks, not clinical validation. No patient data was used.

## Passed checks

- 47 Python tests, including six new importer-bundle/CSP checks.
- 23 JavaScript test scripts: the retained 22 scripts and a new worker-runtime failure/transport test. The second-reader test uses the new loader rather than the old direct factory.
- 7 browser smoke checks: all importer scripts initialize inline with zero startup subrequests; real generated-number OCR self-check; two primary workers; synthetic ZIP/image extraction and six-number recognition by both primary workers; real secondary-model recognition; same-origin missing-library recovery; no POSTs or external OCR requests.
- 4 browser failure/recovery checks: missing English model rejects promptly; retry succeeds after restoration; blocked worker produces a specific error; self-check does not interrupt extraction.
- Exact regression parity for 100 bilateral payloads / 200 eyes, evenly split between baseline and longitudinal. Full returned calculation/audit structures were compared after removing UI version, with PDF generation disabled.
- Byte-for-byte preservation of all three model files and all 13 cornea-rendering/geometry files versus the source deployed in `fictional-waffle` at inspection.
- Vendored OCR assets and both English recognition models are unchanged.

## Browser test method

Chromium ran the actual browser library, actual Web Workers, actual WebAssembly engine, and actual English traineddata. Synthetic digits were drawn onto a canvas, encoded as PNG, placed in a JSZip archive, decoded again, and recognized by the two primary workers. Both returned `7.20 5.80 480 52.0 5.20 260`. A separate real secondary worker returned `12345`.

This environment disallows browser URL navigation. Tests used `set_content` with an explicit static fixture base and intercepted GET responses from the local packaged files. The production CSP script hashes stayed enforced; the fixture origin was admitted in the policy's self-origin slots. Parent message delivery was suppressed only for NKPI messages to the opaque test origin. OCR calculations were not mocked. The browser tests exercised the opaque-origin/blob transport; direct same-origin selection and fallback behavior were unit-tested with worker factories, not a deployed browser session.

The historical earlier package can fail before worker creation when its external Tesseract script is unavailable. The new default importer makes no such library request. The exact clinic-side cause of the historical request failure was not proven.

## Not tested / limitations

No actual Streamlit server or Community Cloud session, no clinic network or managed Windows browser, no pictured patient ZIP, no complete new Pentacam report-to-score run, no native-device anatomical validation, and no clinical accuracy study. Streamlit installation was attempted but the package host could not be resolved from this environment. Python tests used 3.13; the deployment target remains 3.12. Existing report/PDF generation is unchanged and was not revalidated in this patch.

A self-check pass verifies OCR availability, not the correctness of a patient's extracted measurements. The source-review gates remain mandatory. Institutional restrictions that block required browser features or same-origin assets cannot be overridden by this code.

Machine-readable records: `ocr_repair_checks/`.
