"""Real browser checks, synthetic data only; not clinical validation."""
from pathlib import Path
import json,shutil,os,hashlib
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=Path(os.environ.get('FLUID_CHECK_OUT','/mnt/data/nkpi_fluid/testing'));O.mkdir(parents=True,exist_ok=True)
scripts=['image_regions.js','cornea/surface_schema.js','cornea/shape_inspection.js','cornea/anatomical_eye.js','cornea/patient_shape.js','cornea/integrated_model.js','cornea/integrated_measurements.js','cornea/integrated_coverage.js','cornea/continuous_review.js','cornea/natural_eye_base.js','cornea/integrated_eye.js','replay/replay_math.js','replay/gif_encoder.js','replay/webm_encoder.js','replay/fluid_renderer.js','replay/replay_view.js']
html='<html><head><meta charset="utf-8"><style>body{font-family:Arial;background:#f6f3fa;margin:20px}#host{max-width:1100px;margin:auto}</style>'
for f in ['cornea/integrated_eye.css','replay/replay.css']:html+='<style>'+(R/'components'/f).read_text()+'</style>'
html+='</head><body><main id="host"></main>'
for f in scripts:html+='<script>'+(R/'components'/f).read_text().replace('</script','<\\/script')+'</script>'
html+='<script>window.fixture='+ (R/'tests/fixtures/fluid_pair.json').read_text()+';window.before=JSON.stringify(fixture);window.player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results,{syntheticLabel:true,forceWebGL:true});</script></body></html>'
(O/'fluid_harness.html').write_text(html)
report={'checks':[],'errors':[],'limitations':'set_content; synthetic paired surfaces; no live Streamlit or patient case; virtual graphics'}
def check(label,ok,detail=None):
 print(('PASS ' if ok else 'FAIL ')+label,detail or '',flush=True);report['checks'].append({'name':label,'passed':bool(ok),'details':detail})
 (O/'fluid_browser_report.json').write_text(json.dumps(report,indent=2))
 if not ok:raise AssertionError(label)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader'])
 page=b.new_page(viewport={'width':1280,'height':1500},accept_downloads=True);page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.set_content(html,wait_until='load');page.click('[data-rp-prepare]');page.wait_for_function('player.getInfo().prepared',timeout=45000)
 check('Continuous mode defaults and starts after Prepare',page.evaluate('player.getInfo().playing && player.getInfo().mode==="smooth"'))
 check('Playback controls above the eye panel',page.locator('[data-rp-play]').bounding_box()['y']<page.locator('[data-rp-canvas]').bounding_box()['y'])
 page.wait_for_timeout(3200);info=page.evaluate('player.getInfo()');check('Playback advances beyond 13 poses',info['fractionChanges']>20,info)
 check('No cached image sequence',info['cachedImageFrames']==0)
 check('GPU shaders compile and render',all(v=='WebGL continuous geometry' for v in info['backend'].values()),info['backend'])
 page.click('[data-rp-play]');t=page.evaluate('player.getInfo().t');page.wait_for_timeout(200);check('Pause holds position',page.evaluate('player.getInfo().t')==t)
 page.click('[data-rp-play]');page.wait_for_timeout(150);check('Resume does not restart baseline',page.evaluate('player.getInfo().t')>=t);page.click('[data-rp-play]')
 page.evaluate('player.compose(.5)');page.select_option('[data-rp-view]','profile');check('Camera change preserves position',abs(page.evaluate('player.getInfo().t')-.5)<1e-9)
 page.select_option('[data-rp-gain]','5');check('Magnification labeled; sources untouched',page.locator('[data-rp-gain-notice]').is_visible() and page.evaluate('before===JSON.stringify(fixture)'))
 # Hash only the corneal region, excluding status band, numbers and timeline.
 hashes=page.evaluate('''async()=>{const out=[];for(let i=0;i<21;i++){player.capture(i/20);const d=document.querySelector('[data-rp-canvas]').getContext('2d').getImageData(40,155,480,350).data;let h=2166136261;for(let k=0;k<d.length;k++){h^=d[k];h=Math.imul(h,16777619);}out.push(h>>>0);}return out;}''')
 check('21 distinct corneal renders, not merely changing labels',len(set(hashes))>=19,len(set(hashes)))
 page.evaluate('player.compose(.5)');page.locator('.rp-root').screenshot(path=str(O/'fluid_profile_x5.png'))
 page.select_option('[data-rp-field]','thickness');page.select_option('[data-rp-view]','front');page.locator('.rp-root').screenshot(path=str(O/'fluid_thickness.png'))
 check('Maps preserve verified scalar values',page.evaluate('before===JSON.stringify(fixture)'))
 page.select_option('[data-rp-field]','shape');page.select_option('[data-rp-view]','oblique');page.select_option('[data-rp-duration]','4')
 with page.expect_download(timeout=45000) as pending:page.click('[data-rp-video]')
 d=pending.value;video=O/'synthetic_fluid.webm';d.save_as(str(video));page.wait_for_function('!player.getInfo().busy')
 check('Real video exported',video.stat().st_size>10000,video.stat().st_size)
 check('Movie opens in page',page.locator('[data-rp-preview]').is_visible() and page.evaluate('document.querySelector("[data-rp-preview-video]").src.startsWith("blob:")'))
 with page.expect_download(timeout=90000) as pending:page.click('[data-rp-gif]')
 d=pending.value;gif=O/'synthetic_fluid.gif';d.save_as(str(gif));page.wait_for_function('!player.getInfo().busy')
 check('Streaming animated GIF exported',gif.stat().st_size>10000,gif.stat().st_size)
 page.evaluate('player.exportGIF();void 0');page.wait_for_function('player.getInfo().busy');page.click('[data-rp-cancel]');page.wait_for_timeout(200)
 check('GIF cancel restores controls',page.evaluate('!player.getInfo().busy&&player.getInfo().prepared'))
 page.evaluate('player.exportVideo();void 0');page.wait_for_function('player.getInfo().busy');page.click('[data-rp-cancel]');page.wait_for_timeout(250)
 check('Video cancel restores controls',page.evaluate('!player.getInfo().busy&&player.getInfo().prepared'))
 page.evaluate('player();player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results,{forceCanvas:true,syntheticLabel:true});void 0');page.click('[data-rp-prepare]');page.wait_for_function('player.getInfo().prepared');page.wait_for_timeout(1800)
 ci=page.evaluate('player.getInfo()');check('Canvas fallback continuous geometry',ci['fractionChanges']>15 and all(v=='Canvas continuous geometry' for v in ci['backend'].values()),ci)
 page.evaluate('player.compose(.5)');page.locator('.rp-root').screenshot(path=str(O/'fluid_canvas_fallback.png'))
 page.evaluate('player();player=NKPIReplay.mount(document.getElementById("host"),{},fixture.results);void 0');check('Scalars do not fabricate geometry',page.locator('[data-rp-prepare]').is_disabled())
 page.evaluate('player();bad=JSON.parse(JSON.stringify(fixture));bad.sets.OD[1].surface.x_mm[0]-=.01;player=NKPIReplay.mount(document.getElementById("host"),{OD:bad.sets.OD},fixture.results);player.prepare(false);void 0');page.wait_for_function('!player.getInfo().busy');check('Changed grid rejects morphing',not page.evaluate('player.getInfo().prepared'))
 page.evaluate('player();player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results);player.prepare();player();player=NKPIReplay.mount(document.getElementById("host"),{},{});void 0');page.wait_for_timeout(300);check('New case cancels obsolete preparation',not page.evaluate('player.getInfo().prepared'))
 page.emulate_media(reduced_motion='reduce');page.evaluate('player();player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results);player.prepare();void 0');page.wait_for_function('player.getInfo().prepared');check('Reduced-motion respected',not page.evaluate('player.getInfo().playing'))
 page.set_viewport_size({'width':430,'height':950});page.locator('.rp-root').screenshot(path=str(O/'fluid_mobile.png'));check('Mobile controls fit',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
 check('Sources unchanged after all interactions',page.evaluate('before===JSON.stringify(fixture)'));check('No browser errors',not report['errors'],report['errors']);b.close()
print('WROTE',O/'fluid_browser_report.json',flush=True)
