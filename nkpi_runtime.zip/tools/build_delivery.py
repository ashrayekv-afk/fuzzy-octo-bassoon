"""Build a single delivered component from archived sources and local assets.
No network access, credentials or report data. Run by the hash-checked launcher.
"""
from __future__ import annotations
from pathlib import Path
import base64, gzip, hashlib, re, json

RELEASE='9.2.1-fluid-replay'
def compressed(data: bytes)->str:
    return base64.b64encode(gzip.compress(data,compresslevel=6,mtime=0)).decode('ascii')
def build(runtime: Path)->dict:
    runtime=Path(runtime).resolve(); root=runtime/'components'; old=root/'extractor'
    text=(old/'index.html').read_text(encoding='utf-8')
    hashes=[];deferred=[]
    def path(name,relative):
        p=(relative/name.split('?',1)[0]).resolve()
        if not p.is_relative_to(root) or not p.is_file():raise ValueError('Invalid bundled asset: '+name)
        return p
    def inline(content,name,hash_it=False):
        content=re.sub('</script',r'<\\/script',content,flags=re.I)
        content='\n'+content+'\n'
        if hash_it:hashes.append("'sha256-"+base64.b64encode(hashlib.sha256(content.encode()).digest()).decode()+"'")
        return '<script data-nkpi-source="'+name+'">'+content+'</script>'
    def exscript(m):
        name=m[1];content=path(name,old).read_text(encoding='utf-8')
        # about:srcdoc has no navigable relative location. Only delivery/base URL
        # references are compiled; archived field-reading source files are unchanged.
        content=content.replace('window.location.href','document.baseURI').replace('window.location.origin','new URL(document.baseURI).origin')
        tag=inline(content,name,True)
        if 'tesseract.min.js' in name:
            tag+=inline((root/'delivery/ocr_delivery.js').read_text(),'delivery/ocr_delivery.js',True)
        if re.search(r'\bdefer\b',m[0]):deferred.append(tag);return ''
        return tag
    def exstyle(m):
        return '<style>\n'+path(m[1],old).read_text(encoding='utf-8')+'\n</style>'
    text=re.sub(r'<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*</script>',exscript,text)
    text=re.sub(r'<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*/?>',exstyle,text)
    text=text.replace('<head>','<head><!-- NKPI_BASE -->',1)
    # Model and engine bytes are identical to the archived release.
    assets={
      'nkpi-worker':'vendor/tesseract-v7/worker.min.js',
      'nkpi-core-portable':'vendor/tesseract-v7/tesseract-core-lstm.wasm.js',
      'nkpi-core-simd':'vendor/tesseract-v7/tesseract-core-simd-lstm.wasm.js',
      'nkpi-core-relaxed':'vendor/tesseract-v7/tesseract-core-relaxedsimd-lstm.wasm.js',
      'nkpi-model-primary':'ocr_data/eng.traineddata',
      'nkpi-model-secondary':'ocr_second/eng.traineddata',
    }
    embed='\n'.join('<script type="application/octet-stream" id="'+key+'">'+compressed((old/rel).read_bytes())+'</script>' for key,rel in assets.items())
    guard=inline((root/'delivery/extractor_guard.js').read_text(),'delivery/extractor_guard.js',True)
    text=text.replace('</body>',embed+'\n'+'\n'.join(deferred)+guard+'\n</body>')
    policy="default-src 'self'; script-src 'self' https://cdn.jsdelivr.net 'unsafe-eval' "+' '.join(hashes)+"; worker-src 'self' blob: https://cdn.jsdelivr.net; connect-src 'self' blob: data: https://cdn.jsdelivr.net; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; font-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'none';"
    text,count=re.subn(r'<meta\s+http-equiv="Content-Security-Policy"\s+content="[^"]*"\s*/?>','<meta http-equiv="Content-Security-Policy" content="'+policy+'" />',text)
    if count!=1 or re.search(r'<script\b[^>]*src=',text):raise ValueError('Extractor bundling was incomplete')
    # The legacy caching sentence was misleading: cacheMethod has always been none.
    text=text.replace('The English recognition model is bundled with this app. It loads locally from the app on first use and is normally cached.','The original English recognition models are included in this page. Worker setup is browser preparation, not a patient visit.')
    compiled=text.encode('utf-8')
    # Testable delivery output. Original extractor/index.html remains untouched.
    (root/'extractor.compiled.html').write_bytes(compiled)
    main=(root/'index.template.html').read_text(encoding='utf-8')
    def mainscript(m):return inline(path(m[1],root).read_text(encoding='utf-8'),m[1])
    def mainstyle(m):return '<style>\n'+path(m[1],root).read_text(encoding='utf-8')+'\n</style>'
    main=re.sub(r'<link rel="stylesheet" href="([^"]+)">',mainstyle,main)
    main=re.sub(r'<script src="([^"]+)"></script>',mainscript,main)
    payload='<script type="application/octet-stream" id="nkpi-extractor-document">'+compressed(compiled)+'</script>'
    main=main.replace('</body>',payload+inline((root/'delivery/mount_extractor.js').read_text(),'delivery/mount_extractor.js')+'</body>')
    (root/'index.html').write_text(main,encoding='utf-8')
    result={'release':RELEASE,'source_release':'9.1.0 / 2026-10-27','extractor_bytes':len(compiled),'component_bytes':len(main.encode()),'extractor_sha256':hashlib.sha256(compiled).hexdigest(),'component_sha256':hashlib.sha256(main.encode()).hexdigest(),'inline_extractor_scripts':len(hashes)}
    (runtime/'.nkpi-delivery.json').write_text(json.dumps(result,indent=2))
    return result
if __name__=='__main__':print(json.dumps(build(Path(__file__).resolve().parents[1]),indent=2))
