from pathlib import Path
import sys,json,threading,time,traceback,tempfile
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=Path(tempfile.mkdtemp(prefix='nkpi-delivery-checks-'));print('Verification output:',OUT,flush=True)
sys.path.insert(0,str(ROOT));from nkpi.service import configuration
CONFIG=configuration(); requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  requests.append(self.path)
  if self.path=='/':
   data=('''<!doctype html><html><body style="margin:0"><iframe id="main" src="/component/nkpi_test/index.html" style="width:100%;height:4000px;border:0"></iframe><script>const config='''+json.dumps(CONFIG)+''';addEventListener('message', e=>{if(e.source!==document.getElementById('main').contentWindow)return;if(e.data.type==='streamlit:componentReady')e.source.postMessage({type:'streamlit:render',args:{config:config,response:null},disabled:false},location.origin);});</script></body></html>''').encode();typ='text/html'
  elif self.path.startswith('/component/nkpi_test/'):
   rel=self.path.split('?',1)[0].removeprefix('/component/nkpi_test/');p=(ROOT/'components'/rel).resolve()
   if not p.is_relative_to(ROOT/'components') or not p.is_file():self.send_error(404);return
   data=p.read_bytes();typ='text/html' if p.suffix=='.html' else 'application/javascript'
  else:self.send_error(404);return
  self.send_response(200);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();URL=f'http://127.0.0.1:{server.server_port}'
report={'checks':[],'errors':[],'requests':requests}
def check(name,ok,detail=None):
 report['checks'].append({'name':name,'pass':bool(ok),'detail':detail});print('PASS' if ok else 'FAIL',name,detail or '',flush=True)
 if not ok:raise AssertionError(name)
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader']);page=browser.new_page(viewport={'width':1300,'height':1000});page.on('pageerror',lambda e:report['errors'].append(str(e)))
  page.context.on('request',lambda req:requests.append(req.url) if req.url.startswith(('http://','https://')) else None)
  page.on('console',lambda m:print('CONSOLE',m.type,m.text[:250],flush=True) if m.type=='error' else None)
  # Managed Chromium blocks URL navigation here. Exercise the actual bundled
  # component and nested srcdoc from an opaque fixture, retaining CSP hashes.
  html=(ROOT/'components/index.html').read_text().replace('<head>','<head><base href="https://nkpi.test/component/nkpi_test/index.html">',1)
  page.set_content(html,wait_until='load',timeout=45000)
  page.wait_for_function("document.getElementById('extractor-frame').contentDocument?.getElementById('processButton')",timeout=30000)
  main=page.main_frame;child=main.child_frames[0]
  check('production component and nested srcdoc importer loaded (opaque fixture)',child.locator('#processButton').count()==1)
  check('no nested importer or OCR asset requests',not any('extractor/' in x or 'traineddata' in x or 'worker.min' in x for x in requests),list(requests))
  child.wait_for_function("typeof discoverNamedReports==='function' && typeof extractStudy==='function'",timeout=30000)
  check('original archive reader loaded',True)
  t=time.monotonic();print('Starting both actual OCR workers...',flush=True)
  info=child.evaluate('''async()=>{await ensureWorkers();return NKPILegacyDelivery.info();}''');check('both real primary OCR workers ready',info['active']==2,info);report['worker_seconds']=time.monotonic()-t
  result=child.evaluate('''async()=>{const c=document.createElement('canvas');c.width=1200;c.height=120;const x=c.getContext('2d');x.fillStyle='white';x.fillRect(0,0,c.width,c.height);x.fillStyle='black';x.font='52px Arial';x.fillText('7.20 5.80 480 52.0 5.20 260',35,80);return await Promise.all(state.workers.map(w=>recognize(w,c,{psm:7})));}''')
  for i,r in enumerate(result):check('primary '+str(i)+' reads exact synthetic values','7.20 5.80 480 52.0 5.20 260' in r['text'],r['text'])
  sec=child.evaluate('''async()=>{const w=await ensureSecondaryWorker();const c=document.createElement('canvas');c.width=400;c.height=100;const x=c.getContext('2d');x.fillStyle='white';x.fillRect(0,0,400,100);x.fillStyle='black';x.font='48px Arial';x.fillText('12345',30,70);return (await recognize(w,c,{psm:7})).text;}''');check('original secondary model reads synthetic digits','12345' in sec,sec)
  check('still no HTTP OCR requests',not any('traineddata' in x or 'worker.min' in x or 'wasm' in x for x in requests),list(requests))
  report['bridge_limit']='Real same-origin Streamlit message delivery is not tested in this opaque fixture.'
  page.screenshot(path=str(OUT/'delivery_ready.png'))
  child.locator('#age').fill('25')
  child.locator('#baselineZip').set_input_files(str(ROOT/'tests/fixtures/synthetic_pair.zip'))
  print('Running original extractor on synthetic two-eye report ZIP...',flush=True)
  t=time.monotonic()
  values=child.evaluate("""async()=>{await processFiles();return {studies:state.baselineStudies.map(s=>({eye:s.eye,values:s.values,complete:s.complete,warning:s.extractionWarning})),jobs:state.ocrJobsDone};}""")
  report['synthetic_archive']=values;report['synthetic_archive_seconds']=time.monotonic()-t
  print('SYNTHETIC RESULT',json.dumps(values),flush=True)
  check('both synthetic studies assigned to their printed eyes',sorted(s['eye'] for s in values['studies'])==['OD','OS'])
  check('original reader actually ran report OCR jobs',values['jobs']>0,values['jobs'])
  # Record every recovered field without equating a simple fixture to clinical validation.
  expected={'OD':{'A':7.2,'B':5.8,'C':480,'Kmax':52.0,'BAD_D':5.2,'ARTmax':260},'OS':{'A':7.1,'B':5.7,'C':470,'Kmax':53.0,'BAD_D':6.2,'ARTmax':235}}
  match=sum(1 for s in values['studies'] for k,v in expected[s['eye']].items() if s['values'].get(k)==v)
  report['synthetic_exact_fields']=match
  check('synthetic report fields exactly match their printed values',match==12,match)
  check('no HTTP OCR requests during complete report extraction',not any('traineddata' in x or 'worker.min' in x or 'wasm' in x for x in requests),list(requests))
  page.screenshot(path=str(OUT/'synthetic_extraction.png'))
  error=child.evaluate('''async()=>{const old=ensureWorkers;ensureWorkers=async()=>{throw new Error('Synthetic blocked-worker test')};try{await parseArchive(new File(['x'],'fixture.zip'),'Single visit');}catch(e){return String(e.message);}finally{ensureWorkers=old;}}''');check('failed OCR stops automatic extraction','Automatic extraction stopped:' in error,error)
  check('no browser exceptions',not report['errors'],report['errors'])
  browser.close()
except Exception as e:report['failure']=repr(e);print(traceback.format_exc(),flush=True)
finally:(OUT/'delivery_checks.json').write_text(json.dumps(report,indent=2));server.shutdown()
