from pathlib import Path
import json,time,re,tempfile,subprocess,os,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=Path(tempfile.mkdtemp(prefix='nkpi-replay-checks-'))
print('Verification output:',OUT,flush=True)
report={'checks':[], 'errors':[]}
def check(label,okay,details=None):
 report['checks'].append({'name':label,'passed':bool(okay),'details':details});print('PASS' if okay else 'FAIL',label,details or '',flush=True)
 if not okay: raise AssertionError(label)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM') or shutil.which('chromium'),headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader'])
 page=browser.new_page(viewport={'width':1200,'height':1300},accept_downloads=True)
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 subprocess.run(['node',str(ROOT/'tests/test_replay.cjs')],env={**os.environ,'WRITE_REPLAY_FIXTURE':str(OUT/'fixture.json')},check=True,capture_output=True)
 fixture=(OUT/'fixture.json').read_text()
 scripts=['image_regions.js','cornea/surface_schema.js','cornea/shape_inspection.js','cornea/anatomical_eye.js','cornea/patient_shape.js','cornea/integrated_model.js','cornea/integrated_measurements.js','cornea/integrated_coverage.js','cornea/continuous_review.js','cornea/natural_eye_base.js','cornea/integrated_eye.js','replay/replay_math.js','replay/gif_encoder.js','replay/replay_view.js']
 html='<html><head><meta charset="utf-8"><style>body{font-family:Arial;background:#f6f3fa;margin:20px}#host{max-width:1100px;margin:auto}</style>'
 for f in ['cornea/integrated_eye.css','replay/replay.css']:html+='<style>'+(ROOT/'components'/f).read_text()+'</style>'
 html+='</head><body><h1>SYNTHETIC ENGINEERING TEST — NOT PATIENT DATA</h1><main id="host"></main>'
 for f in scripts:html+='<script>'+(ROOT/'components'/f).read_text().replace('</script','<\\/script')+'</script>'
 html+='<script>window.fixture='+fixture+';window.before=JSON.stringify(fixture);window.player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results);</script></body></html>'
 page.set_content(html,wait_until='load',timeout=15000)
 page.click('[data-rp-prepare]')
 page.wait_for_function('window.player.getInfo().prepared && !window.player.getInfo().busy',timeout=30000)
 info=page.evaluate('player.getInfo()');check('Observed endpoints prepared for both eyes',info['frameCounts']=={'OD':2,'OS':2},info)
 check('Source reports and verified numbers unchanged',page.evaluate('before===JSON.stringify(fixture)'))
 page.locator('.rp-root').screenshot(path=str(OUT/'replay_natural.png'))
 page.click('[data-rp-play]');page.wait_for_timeout(3300)
 check('Play advances to latest observed endpoint',page.locator('[data-rp-scrub]').input_value()=='1000')
 page.click('[data-rp-play]')
 page.select_option('[data-rp-mode]','smooth')
 page.wait_for_function('player.getInfo().prepared && !player.getInfo().busy',timeout=45000)
 info=page.evaluate('player.getInfo()');check('Smooth mode creates 13 display frames per eye',info['frameCounts']=={'OD':13,'OS':13},info)
 page.evaluate('player.compose(.5)');page.locator('.rp-root').screenshot(path=str(OUT/'replay_middle.png'))
 with page.expect_download(timeout=60000) as pending:page.click('[data-rp-gif]')
 download=pending.value;download.save_as(str(OUT/'synthetic_replay.gif'));check('Local GIF download', (OUT/'synthetic_replay.gif').stat().st_size>100000,download.suggested_filename)
 page.wait_for_function('!player.getInfo().busy')
 page.select_option('[data-rp-duration]','4')
 if page.locator('[data-rp-video]').is_enabled():
  with page.expect_download(timeout=20000) as pending:page.click('[data-rp-video]')
  download=pending.value;ext=Path(download.suggested_filename).suffix;download.save_as(str(OUT/('synthetic_replay'+ext)));check('Browser video export',(OUT/('synthetic_replay'+ext)).stat().st_size>10000,download.suggested_filename)
 else:check('Unsupported video disables button',True)
 page.select_option('[data-rp-view]','profile');page.wait_for_function('player.getInfo().prepared && !player.getInfo().busy',timeout=45000)
 page.evaluate('player.compose(.5)');page.locator('.rp-root').screenshot(path=str(OUT/'replay_profile.png'))
 check('Camera change preserves verified values',page.evaluate('before===JSON.stringify(fixture)'))
 page.select_option('[data-rp-field]','thickness');page.wait_for_function('player.getInfo().prepared && !player.getInfo().busy',timeout=45000)
 page.evaluate('player.compose(1)');page.locator('.rp-root').screenshot(path=str(OUT/'replay_thickness.png'))
 check('Thickness mode retains source values',page.evaluate('before===JSON.stringify(fixture)'))
 page.evaluate('player(); player=NKPIReplay.mount(document.getElementById("host"),{},fixture.results);void 0')
 check('Scalar values alone cannot animate a cornea',page.locator('[data-rp-prepare]').is_disabled())
 page.evaluate('player(); player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results,{forceCanvas:true});void 0')
 page.click('[data-rp-prepare]');page.wait_for_function('player.getInfo().prepared && !player.getInfo().busy',timeout=45000)
 info=page.evaluate('player.getInfo()');check('Original software renderer fallback has two observed frames',info['frameCounts']=={'OD':2,'OS':2},info)
 page.select_option('[data-rp-mode]','smooth');page.wait_for_function('player.getInfo().prepared && !player.getInfo().busy',timeout=60000)
 check('Original software renderer also renders smooth geometry',page.evaluate('player.getInfo().frameCounts.OD===13'))
 page.locator('.rp-root').screenshot(path=str(OUT/'replay_canvas.png'))
 page.evaluate('player();player=NKPIReplay.mount(document.getElementById("host"),fixture.sets,fixture.results);player.prepare();player();player=NKPIReplay.mount(document.getElementById("host"),{},{});void 0')
 page.wait_for_timeout(500);check('New case cancels stale preparation',page.locator('[data-rp-prepare]').is_disabled() and not page.evaluate('player.getInfo().prepared'))
 check('No browser exceptions',not report['errors'],report['errors'])
 browser.close()
(OUT/'browser_report.json').write_text(json.dumps(report,indent=2))
