/* Transport-only adapter for the archived 2026-10-27 extractor.
 * OCR crops, field parsing, consensus, laterality and source review stay in
 * the original files. Upstream engine and model bytes are not modified.
 */
'use strict';
window.NKPILegacyDelivery = (() => {
  const original = window.Tesseract?.createWorker;
  const models = new Map(), urls = new Map(), active = new Set(), pending = new Set();
  let generation = 0, lastError = '', lastPhase = 'idle', started = 0;
  const tests = {
    relaxed: [0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,15,1,13,0,65,1,253,15,65,2,253,15,253,128,2,11],
    simd: [0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,10,1,8,0,65,0,253,15,253,98,11],
  };
  function node(id) {
    const value = document.getElementById(id)?.textContent?.trim();
    if (!value) throw new Error('OCR package is incomplete: '+id+'. Replace both release files together.');
    return value;
  }
  function bytes(text) {
    const decoded = atob(text), data = new Uint8Array(decoded.length);
    for (let i=0;i<decoded.length;i++) data[i]=decoded.charCodeAt(i);
    return data;
  }
  async function unpack(id) {
    const data=bytes(node(id));
    // No patient data is passed to this routine. Only shipped software/model bytes.
    if (typeof DecompressionStream!=='function') throw new Error('This browser cannot unpack the bundled OCR engine. Use a current approved Edge or Chrome browser.');
    return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
  }
  function coreKind(secondary) {
    if (secondary) return 'portable';
    // Identical probes and priority to the original Tesseract 7 worker.
    if (WebAssembly.validate(new Uint8Array(tests.relaxed))) return 'relaxed';
    return WebAssembly.validate(new Uint8Array(tests.simd)) ? 'simd' : 'portable';
  }
  function check() {
    if (typeof original!=='function') throw new Error('The packaged OCR library did not initialize. Reload this release.');
    if (typeof Worker!=='function'||typeof WebAssembly!=='object') throw new Error('This browser blocks local Web Workers or WebAssembly. Automatic extraction cannot run here.');
    return true;
  }
  async function assetSet(kind) {
    check();
    if (!models.has(kind)) models.set(kind, 'data:application/gzip;base64,'+node('nkpi-model-'+kind)+'#bundled-'+kind);
    const engine=coreKind(kind==='secondary');
    if (!urls.has(engine)) {
      urls.set(engine, Promise.all([unpack('nkpi-core-'+engine),unpack('nkpi-worker')]).then(([core,worker])=>{
        return URL.createObjectURL(new Blob([core,'\n;\n',worker,'\n'],{type:'application/javascript'}));
      }));
    }
    return {langPath:models.get(kind),url:await urls.get(engine),engine};
  }
  async function create(langs='eng',oem=1,options={},config={}) {
    const secondary=String(options.langPath||'').includes('ocr_second');
    const kind=secondary?'secondary':'primary', epoch=generation;
    let raw=null,api=null,done=false,timer=null,rejectBoot;
    const interrupted=new Promise((_,reject)=>{rejectBoot=reject;});
    const task={cancel:()=>rejectBoot(new Error('OCR setup cancelled.'))};
    pending.add(task);
    try {
      const asset=await Promise.race([assetSet(kind),interrupted]);
      if(epoch!==generation) throw new Error('OCR session changed.');
      lastPhase='initializing '+kind+' reader';
      const NativeWorker=window.Worker;
      // createWorker synchronously constructs its Web Worker before returning
      // its promise. Capture it so failures/timeouts can terminate it immediately.
      window.Worker=class extends NativeWorker { constructor(url,opts) { super(url,opts); if(url===asset.url)raw=this; } };
      let creation;
      try {
        creation=original('eng',oem,{
          ...options,
          workerPath:asset.url,workerBlobURL:false,
          corePath:'data:text/javascript,throw%20Error(%22Embedded%20engine%20missing%22)#core.js',
          langPath:asset.langPath,gzip:true,cacheMethod:'none',
          logger: message=>{
            if(done||epoch!==generation)return;
            lastPhase=String(message.status||lastPhase);
            options.logger?.(message);
          },
          errorHandler: error=>{
            lastError=String(error?.message||error||'OCR initialization error');
            if(!done)rejectBoot(new Error('OCR engine failed during '+lastPhase+'. No extraction was completed.'));
          }
        },config);
      } finally {window.Worker=NativeWorker;}
      raw?.addEventListener('error',()=>rejectBoot(new Error('The browser could not run the bundled OCR worker. No extraction was completed.')),{once:true});
      timer=setTimeout(()=>rejectBoot(new Error('OCR did not start within 40 seconds. No report-reading jobs were run.')),40000);
      creation.then(w=>{if(done||epoch!==generation)w.terminate().catch(()=>{});}).catch(()=>{});
      api=await Promise.race([creation,interrupted]);
      if(epoch!==generation)throw new Error('OCR session changed.');
      done=true;active.add(api);started++;
      const terminate=api.terminate.bind(api);
      api.terminate=async()=>{active.delete(api);return terminate();};
      lastPhase='ready';lastError='';
      return api;
    } catch(e) {
      done=true;raw?.terminate();if(api)await api.terminate().catch(()=>{});
      lastError=String(e?.message||e);throw e;
    } finally {clearTimeout(timer);pending.delete(task);}
  }
  function dispose() {
    generation++;for(const task of pending)task.cancel();pending.clear();
    for(const w of active)w.terminate().catch(()=>{});active.clear();
    for(const p of urls.values())p.then(url=>URL.revokeObjectURL(url)).catch(()=>{});
    urls.clear();models.clear();
  }
  if(typeof original==='function')window.Tesseract.createWorker=create;
  window.addEventListener('pagehide',dispose);
  return Object.freeze({check,dispose,info:()=>({source:'2026-10-27 / v9.1.0',started,active:active.size,phase:lastPhase,error:lastError})});
})();
