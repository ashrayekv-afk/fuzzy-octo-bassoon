/* Runtime/UI guard only. The archived extraction sources remain unmodified. */
'use strict';
const legacyParseArchive = parseArchive;
parseArchive = async function(file,label) {
  if(!forceManualImport) {
    try { await ensureWorkers(); }
    catch(error) {
      NKPILegacyDelivery.dispose();
      state.workers=[];state.workerPromise=null;
      throw new Error('Automatic extraction stopped: '+String(error?.message||error));
    }
  }
  return legacyParseArchive(file,label);
};
updateWorkerLoadProgress = function(index,message) {
  if(typeof message.progress!=='number')return;
  state.workerProgress[index]=message.progress;
  const average=(state.workerProgress[0]+state.workerProgress[1])/2;
  setProgress(Math.max(2,Math.round(average*18)),'Starting the bundled report reader…','This is browser setup, not a patient visit. The original October 27 extraction rules are unchanged.');
};
const archivedSetProgress=setProgress;
setProgress=function(percent,title,detail){
  if(title==='Preparing two local OCR workers…'){
    title='Starting the bundled report reader…';detail='The engine is included in this page; no separate OCR file download is required.';
  }
  if(title==='Extraction complete') {
    const studies=[...(state.baselineStudies||[]),...(state.earlierStudies||[]),...(state.laterStudies||[])];
    const count=studies.reduce((n,s)=>n+Object.values(s.values||{}).filter(v=>typeof v==='number'&&Number.isFinite(v)).length,0);
    if(!count){title='No measurements were read';detail='Automatic extraction did not recover any values. No values or eye assignments were invented.';}
  }
  return archivedSetProgress(percent,title,detail);
};
document.addEventListener('DOMContentLoaded',()=>{
  // Automatic extraction stays the primary action. The original optional manual
  // source-page selector is retained inside technical help, not selected by default.
  const manual=document.getElementById('manualPageSelection');
  const help=document.querySelector('.technical-card details');
  if(manual&&help)help.appendChild(manual);
  const footer=document.querySelector('footer');
  if(footer)footer.textContent='Original October 27 extractor · Replay build 9.2.0 · Source verification required';
});
