/* The importer is shipped in this component document, not loaded by a nested URL.
 * Same-origin source/nonce checks remain in the original message bridge.
 */
'use strict';
(() => {
  let textPromise=null, ticket=0;
  async function source() {
    if(!textPromise)textPromise=(async()=>{
      const encoded=document.getElementById('nkpi-extractor-document')?.textContent?.trim();
      if(!encoded)throw new Error('The bundled extractor is missing. Replace both release files together.');
      const binary=atob(encoded),bytes=new Uint8Array(binary.length);
      for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
      const text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
      const base=new URL('extractor/index.html',document.baseURI).href;
      return text.replace('<!-- NKPI_BASE -->','<base href="'+base.replaceAll('&','&amp;').replaceAll('"','&quot;')+'">');
    })();
    return textPromise;
  }
  window.NKPIExtractorMount=async function(frame){
    const mine=++ticket;
    try{
      const html=await source();if(mine!==ticket||!frame.isConnected)return;
      frame.removeAttribute('src');frame.srcdoc=html;
    }catch(error){
      const status=document.getElementById('extractor-delivery-status');
      if(status){status.hidden=false;status.textContent='The packaged importer could not open: '+String(error?.message||error);}
    }
  };
  const frame=document.getElementById('extractor-frame');if(frame)window.NKPIExtractorMount(frame);
})();
