/* Unified patient-only bilateral eye figure. Source geometry and numerical
 * measurements stay in patient_shape.js; this module coordinates the two
 * views without mixing eyes, filling measurements, or changing calculations. */
(function(root){'use strict';
const EYES=['OD','OS'];
const LAYERS=[
 {id:'combined',label:'Curvature + thickness'},
 {id:'anterior',label:'Anterior curvature'},
 {id:'thickness',label:'Thickness'},
 {id:'elevation',label:'Anterior elevation'},
 {id:'posterior_elevation',label:'Posterior elevation'},
 {id:'posterior',label:'Posterior curvature'},
 {id:'form',label:'Surface shape'},
 {id:'shape',label:'Natural eye'}
];
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const cameraKeys=['yaw','pitch','roll','zoom'];
function mount(el,setsByEye={},results={},options={}){
 if(root.NKPIIntegratedEye)return root.NKPIIntegratedEye.mount(el,setsByEye,results,options);
 if(!el||!root.NKPIPatientShape)return ()=>{};
 const A=root.NKPIPatientShape,prepared=new Map(),sets={};
 for(const eye of EYES){sets[eye]=(setsByEye[eye]||[]).filter(s=>s.eye===eye);for(const report of sets[eye]){try{prepared.set(report,A.fromReport(report));}catch(_){/* The individual viewer shows the source error. */}}}
 A.sharedScales([...prepared.values()]);
 const supplied=options.initialState||{};
 const visits=new Set(EYES.flatMap(e=>sets[e].map(s=>s.visit)));
 const defaultVisit=visits.has('latest')?'latest':'first';
 const defaultLayer=LAYERS.find(l=>[...prepared.values()].some(m=>m.overlays.some(o=>o.id===l.id)))?.id||'shape';
 let state={visit:defaultVisit,color:defaultLayer,eyeContext:false,yaw:-.5,pitch:-.2,roll:0,zoom:.88,cut:false,coverage:false,emphasis:1,profile:false,linked:true,...supplied};
 if(!['first','latest'].includes(state.visit))state.visit=defaultVisit;
 if(visits.size&&!visits.has(state.visit))state.visit=defaultVisit;
 if(!LAYERS.some(l=>l.id===state.color))state.color=defaultLayer;
 if(supplied.hasData===false&&visits.size){state.visit=defaultVisit;state.color=defaultLayer;}
 // A new case starts with its best available source layer. A saved mode that
 // is unavailable in this case stays explicitly unavailable until changed.
 const controllers={},dead={value:false};let synchronizing=false;
 const viewerState=()=>({yaw:state.yaw,pitch:state.pitch,roll:state.roll,zoom:state.zoom,eyeContext:state.eyeContext,cut:state.cut,color:state.color,coverage:state.coverage,emphasis:state.emphasis,profile:state.profile});
 el.innerHTML='<section class="rg-bilateral" aria-label="Bilateral 3D corneal figure"><div class="rg-bilateral-heading"><div><span class="rg-tag">CURRENT PATIENT · BOTH EYES</span><h3>Bilateral corneal view</h3></div><div class="rg-actions">'+(options.canCompare?'<button type="button" data-bilateral-change>Change maps ↓</button>':'')+'<button type="button" data-bilateral-save>Save both eyes</button></div></div>'+
 '<div class="rg-bilateral-topbar"><div class="rg-tabs" role="group" aria-label="Scan visit">'+[['first','Baseline'],['latest','Latest']].map(([id,label])=>'<button type="button" data-bilateral-visit="'+id+'">'+label+'</button>').join('')+'</div><label class="rg-bilateral-link"><input type="checkbox" data-bilateral-link checked> Link rotation &amp; zoom</label></div>'+
 '<div class="rg-bilateral-layers" role="group" aria-label="Corneal display layer">'+LAYERS.map(l=>'<button type="button" data-bilateral-layer="'+l.id+'">'+l.label+'</button>').join('')+'</div>'+
 '<div class="rg-bilateral-tools"><label>View <select data-bilateral-context><option value="cornea">Eye detail</option><option value="eye">Whole eye</option></select></label><div class="rg-actions" role="group" aria-label="Camera presets"><button type="button" data-bilateral-view="reset">3D</button><button type="button" data-bilateral-view="front">Front</button><button type="button" data-bilateral-view="profile">Shape profile</button></div><label><input type="checkbox" data-bilateral-cut> Cutaway</label><label><input type="checkbox" data-bilateral-coverage> Source coverage</label><label data-bilateral-relief-label>Relief <select data-bilateral-emphasis><option value="1">True scale</option><option value="3">×3 · display only</option><option value="6">×6 · display only</option></select></label><div class="rg-bilateral-zoom"><button type="button" data-bilateral-zoom="out" aria-label="Zoom both eyes out">−</button><button type="button" data-bilateral-zoom="in" aria-label="Zoom both eyes in">+</button></div></div>'+
 '<p class="rg-bilateral-hint" data-bilateral-hint></p><p class="rg-bilateral-availability" data-bilateral-availability hidden></p><div class="rg-bilateral-grid">'+EYES.map(eye=>'<article class="rg-bilateral-eye" data-bilateral-eye="'+eye+'"><header><h4>'+eye+' · '+(eye==='OD'?'Right eye':'Left eye')+'</h4><span data-bilateral-eye-visit></span></header><div data-bilateral-mount></div></article>').join('')+'</div>'+
 '<p class="rg-bilateral-footnote">Drag either eye to rotate · scroll to zoom · select a corneal point to inspect all available values.</p><details class="rg-details rg-bilateral-method"><summary>What the eye model represents</summary><p>The corneal surface follows available anterior heights or report elevation. The combined view uses anterior curvature color with white thickness contours on that same surface. Posterior maps are shown at their corneal locations on the outer display surface.</p><p>Coordinates and map values are kept in physical units. Native device heights support the closest reconstruction. Report-image geometry is approximate because the printed map does not specify the reference sphere’s full position and tilt. Missing measurements remain unavailable. Surface completion is a visual continuation, with its support visible under Source coverage.</p><p>The globe, iris and unmeasured peripheral cornea are reference anatomy. A report image cannot establish an exact whole-eye replica. Compatible map definitions use the same numerical color bounds across eyes and visits. Different source types or map definitions keep separate scales, as labeled under each eye.</p><p>Baseline and latest are separate reconstructions. Change maps compare the available paired measurements in the section below; they are not a registered 3D deformation. True scale is the default. Optional relief amplifies only image-derived elevation for display and leaves measurements and calculations unchanged.</p></details></section>';
 function onView(eye,view){
  if(dead.value||synchronizing)return;
  for(const k of cameraKeys)if(Number.isFinite(view[k])&&!(state.profile&&k==='roll'))state[k]=view[k];
  if(!state.linked)return;
  synchronizing=true;const patch={};for(const k of cameraKeys)if(Number.isFinite(view[k])&&!(state.profile&&k==='roll'))patch[k]=view[k];
  for(const other of EYES)if(other!==eye)controllers[other]?.setState(patch,{silent:true});
  synchronizing=false;
 }
 for(const eye of EYES){
  const card=el.querySelector('[data-bilateral-eye="'+eye+'"]');
  controllers[eye]=A.mount(card.querySelector('[data-bilateral-mount]'),sets[eye],eye,results[eye]||null,{embedded:true,initialState:viewerState(),visit:state.visit,preparedModels:prepared,onViewChange:view=>onView(eye,view)});
 }
 function infos(){return EYES.map(eye=>({eye,...(controllers[eye]?.getInfo?.()||{})}));}
 function sync(){
  const all=infos();
  if(!all.some(v=>v.kind==='estimated'))state.emphasis=1;
  for(const b of el.querySelectorAll('[data-bilateral-visit]')){const active=b.dataset.bilateralVisit===state.visit;b.setAttribute('aria-pressed',String(active));b.disabled=!visits.has(b.dataset.bilateralVisit);b.title=b.disabled?'No linked '+(b.dataset.bilateralVisit==='first'?'baseline':'latest')+' scan for either eye':'';}
  for(const b of el.querySelectorAll('[data-bilateral-layer]')){const id=b.dataset.bilateralLayer,available=all.some(v=>v.overlays?.some(l=>l.id===id));b.disabled=!available;b.setAttribute('aria-pressed',String(state.color===id));b.title=available?'Apply '+b.textContent.toLowerCase()+' to both eyes':'This field is unavailable in the linked '+(state.visit==='latest'?'latest':'baseline')+' scans';}
  el.querySelector('[data-bilateral-context]').value=state.eyeContext?'eye':'cornea';
  el.querySelector('[data-bilateral-link]').checked=state.linked;
  el.querySelector('[data-bilateral-cut]').checked=state.cut;
  el.querySelector('[data-bilateral-coverage]').checked=state.coverage;
  const hasGeometry=all.some(v=>v.hasGeometry),hasEstimated=all.some(v=>v.kind==='estimated');
  const profile=el.querySelector('[data-bilateral-view="profile"]');profile.disabled=!hasGeometry;profile.setAttribute('aria-pressed',String(state.profile));profile.title=hasGeometry?'Inspect each cornea from its own source meridian':'Requires anterior surface height or elevation data';
  el.querySelector('[data-bilateral-relief-label]').hidden=!hasEstimated;
  el.querySelector('[data-bilateral-emphasis]').value=String(state.emphasis);
  for(const v of all){const card=el.querySelector('[data-bilateral-eye="'+v.eye+'"]');card.querySelector('[data-bilateral-eye-visit]').textContent=(state.visit==='latest'?'Latest':'Baseline')+(v.hasData?'':' · no scan linked');}
  const missing=LAYERS.filter(l=>!['shape','form','combined'].includes(l.id)&&!all.some(v=>v.overlays?.some(q=>q.id===l.id))),availability=el.querySelector('[data-bilateral-availability]');
  availability.hidden=!all.some(v=>v.hasData)||!missing.length;
  availability.textContent=missing.length?'Fields unavailable at this visit: '+missing.map(l=>l.label.toLowerCase()).join(', ')+'. The corresponding controls stay disabled.':'';
  const hint=el.querySelector('[data-bilateral-hint]');
  const coverageHint=['shape','form'].includes(state.color)?'Teal marks source-supported geometry, amber marks visual surface completion, and gray marks reference anatomy.':(state.color==='combined'?'Anterior-curvature map coverage: ':'Selected-map coverage: ')+'teal marks available source values, amber marks small interpolated image-map gaps, and gray marks unavailable values or reference anatomy.';
  hint.textContent=!all.some(v=>v.hasData)?'Import your reports, verify the measurements and calculate to link the patient’s corneal data to these two views.':state.coverage?coverageHint:state.color==='combined'?'Curvature color + thickness contours + the available elevation-based surface. Both eyes use the same selected display.':state.color==='form'?'Solid shading makes the surface contour easier to inspect. Select Shape profile for a side view and source cross-section.':state.color==='shape'?'Clear corneal surface over a reference iris. Rotate to inspect the corneal contour.':'The selected map follows each eye’s surface. Read the units and source-specific scale under each eye.';
 }
 function setAll(patch){
  Object.assign(state,patch);synchronizing=true;
  for(const eye of EYES)controllers[eye]?.setState(patch,{silent:true});
  synchronizing=false;
  if(patch.view){const actual=controllers.OD?.getState?.()||controllers.OS?.getState?.();if(actual)for(const k of cameraKeys)state[k]=actual[k];}
  sync();
 }
 function setVisit(visit){state.visit=visit;for(const eye of EYES)controllers[eye]?.setVisit(visit);if(!infos().some(v=>v.kind==='estimated'))state.emphasis=1;for(const eye of EYES)controllers[eye]?.setState({emphasis:state.emphasis},{silent:true});sync();}
 function preset(view){
  state.profile=view==='profile';state.zoom=view==='reset'?.88:1;state.roll=0;
  if(view==='profile'){state.eyeContext=false;state.cut=false;}
  if(view==='reset'){state.yaw=-.5;state.pitch=-.2;}
  if(view==='front'){state.yaw=0;state.pitch=0;}
  // Each eye determines its own source meridian; no source coordinates move.
  for(const eye of EYES)controllers[eye]?.setState({view},{silent:true});
  const first=controllers.OD?.getState?.();if(first)for(const k of cameraKeys)state[k]=first[k];sync();
 }
 function wrap(ctx,text,width){const lines=[];let line='';for(const word of String(text).split(/\s+/)){const next=line?line+' '+word:word;if(line&&ctx.measureText(next).width>width){lines.push(line);line=word;}else line=next;}if(line)lines.push(line);return lines;}
 function saveFigure(){
  const canvases=EYES.map(eye=>{const c=controllers[eye];c?.draw?.();return c?.exportCanvas?.()||c?.getCanvas?.();});
  if(canvases.some(c=>!c))return;
  const out=document.createElement('canvas'),width=1680,pad=36,gap=24,panel=(width-pad*2-gap)/2;
  const heights=canvases.map(c=>Math.round(panel*c.height/c.width)),top=118,maxHeight=Math.max(...heights),foot=128;
  out.width=width;out.height=top+maxHeight+foot;const ctx=out.getContext('2d');ctx.fillStyle='#f7f5fa';ctx.fillRect(0,0,width,out.height);
  ctx.fillStyle='#30243e';ctx.font='700 29px system-ui';ctx.fillText('NKPI · Bilateral corneal view',pad,44);ctx.font='20px system-ui';
  ctx.fillText((state.visit==='latest'?'Latest':'Baseline')+' · '+(LAYERS.find(l=>l.id===state.color)?.label||state.color)+' · '+(state.emphasis>1?'Report-image relief ×'+state.emphasis+' (display only)':'True physical scale'),pad,78);
  EYES.forEach((eye,i)=>{const x=pad+i*(panel+gap);ctx.drawImage(canvases[i],x,top,panel,heights[i]);});
  ctx.fillStyle='#5b5265';ctx.font='18px system-ui';let y=top+maxHeight+33;
  const footer=['OD is the right eye. OS is the left eye. Globe and iris are reference anatomy. Report-derived shapes are approximate.','Measurements are shown only where supported by the uploaded source. Baseline/latest surfaces are independent reconstructions.'];
  for(const text of footer)for(const line of wrap(ctx,text,width-pad*2)){ctx.fillText(line,pad,y);y+=26;}
  const a=document.createElement('a');a.download='NKPI_OD_OS_'+state.visit+'_'+state.color+'_v909.png';a.href=out.toDataURL('image/png');a.click();
 }
 function click(event){
  const b=event.target.closest('button');if(!b||b.disabled)return;
  if(b.dataset.bilateralVisit)setVisit(b.dataset.bilateralVisit);
  else if(b.dataset.bilateralLayer)setAll({color:b.dataset.bilateralLayer});
  else if(b.dataset.bilateralView)preset(b.dataset.bilateralView);
  else if(b.dataset.bilateralZoom){const factor=b.dataset.bilateralZoom==='in'?1.15:1/1.15;state.zoom=clamp(state.zoom*factor,.6,1.8);setAll({zoom:state.zoom});}
  else if(b.hasAttribute('data-bilateral-save'))saveFigure();
  else if(b.hasAttribute('data-bilateral-change'))options.onRequestChange?.();
 }
 function change(event){
  const t=event.target;
  if(t.hasAttribute('data-bilateral-context')){state.eyeContext=t.value==='eye';setAll({eyeContext:state.eyeContext,profile:false,cut:false,view:'reset'});}
  else if(t.hasAttribute('data-bilateral-cut'))setAll(t.checked?{cut:true,profile:false,eyeContext:false,yaw:-1.05,pitch:-.10,roll:0}:{cut:false});
  else if(t.hasAttribute('data-bilateral-coverage'))setAll({coverage:t.checked});
  else if(t.hasAttribute('data-bilateral-emphasis'))setAll({emphasis:Number(t.value)});
  else if(t.hasAttribute('data-bilateral-link')){state.linked=t.checked;if(state.linked)setAll(viewerState());}
 }
 el.addEventListener('click',click);el.addEventListener('change',change);sync();
 const dispose=()=>{dead.value=true;for(const eye of EYES)controllers[eye]?.();el.removeEventListener('click',click);el.removeEventListener('change',change);};
 dispose.getState=()=>({...state,hasData:infos().some(v=>v.hasData)});
 dispose.getInfo=()=>infos();
 dispose.exportFigure=saveFigure;
 return dispose;
}
root.NKPIBilateralEye={mount,LAYERS};
})(typeof window!=='undefined'?window:globalThis);
