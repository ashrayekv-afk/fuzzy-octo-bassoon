/* Display-only completion and C reconciliation. No source array or model input
 * is modified. Numerical readouts and minima use the ORIGINAL model only. */
(function(root){'use strict';
const node=typeof module!=='undefined'&&module.exports;
const M=node?require('./integrated_measurements.js'):root.NKPIIntegratedMeasurements;
const C=node?require('./integrated_coverage.js'):root.NKPIIntegratedCoverage;
const F=['thickness','anterior','posterior','elevation','posterior_elevation'];
const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const unit=a=>{const d=Math.hypot(...a)||1;return a.map(v=>v/d);};
function complete(values,w,h,fallback=0){
 // Immutable Dirichlet anchors; nearest initial values, then discrete harmonic
 // completion. Extrapolated/broad areas are NEVER exposed as measurements.
 const a=Float64Array.from(values,v=>finite(v)?v:NaN),fixed=Uint8Array.from(values,v=>finite(v)?1:0);
 const q=new Int32Array(w*h),seen=new Uint8Array(w*h);let head=0,tail=0;
 for(let i=0;i<a.length;i++)if(fixed[i]){q[tail++]=i;seen[i]=1;}
 const count=tail;if(!count){a.fill(fallback);return {values:a,fixed,count};}
 while(head<tail){const k=q[head++],x=k%w,y=Math.floor(k/w);
  for(const j of [x?k-1:-1,x<w-1?k+1:-1,y?k-w:-1,y<h-1?k+w:-1])if(j>=0&&!seen[j]){seen[j]=1;a[j]=a[k];q[tail++]=j;}
 }
 const missing=[];for(let i=0;i<a.length;i++)if(!fixed[i])missing.push(i);
 for(let it=0;it<180&&missing.length;it++){let change=0;
  for(let parity=0;parity<2;parity++)for(const k of missing){const x=k%w,y=Math.floor(k/w);if((x+y)%2!==parity)continue;let sum=0,n=0;
   if(x){sum+=a[k-1];n++;}if(x<w-1){sum+=a[k+1];n++;}if(y){sum+=a[k-w];n++;}if(y<h-1){sum+=a[k+w];n++;}
   const next=sum/n;change=Math.max(change,Math.abs(next-a[k]));a[k]=next;
  }if(change<1e-6)break;
 }
 return {values:a,fixed,count};
}
function interval(axis,value){
 const asc=axis.at(-1)>axis[0];let lo=0,hi=axis.length-1;
 while(hi-lo>1){const m=(lo+hi)>>1;if((value>=axis[m])===asc)lo=m;else hi=m;}
 const t=clamp((value-axis[lo])/(axis[lo+1]-axis[lo]),0,1);return [lo,t];
}
function sample(a,xs,ys,x,y){if(xs.length<2||ys.length<2)return null;const [i,u]=interval(xs,x),[j,v]=interval(ys,y),w=xs.length;
 return a[j*w+i]*(1-u)*(1-v)+a[j*w+i+1]*u*(1-v)+a[(j+1)*w+i]*(1-u)*v+a[(j+1)*w+i+1]*u*v;
}
function neighbors(xs,ys,x,y){const [i,u]=interval(xs,x),[j,v]=interval(ys,y),w=xs.length;return [[j*w+i,(1-u)*(1-v)],[j*w+i+1,u*(1-v)],[(j+1)*w+i,(1-u)*v],[(j+1)*w+i+1,u*v]].filter(p=>p[1]>1e-8);}
function cFor(result,eye,visit){
 const c=result?.case;if(!c||c.eye!==eye||c.verified!==true)return null;
 if(visit==='latest'&&c.mode!=='longitudinal')return null;
 const value=(visit==='latest'?c.latest:c.first)?.C;
 return finite(value)&&value>=100&&value<=2000?{value,eye,visit,label:'Verified C',origin:'Verified calculator input; compare with the same report and visit'}:null;
}
function landmarkFor(report,result,radius){
 // Never reuse an unscoped single landmark on two longitudinal visits.
 const scoped=report?.thinnest_point;
 if(scoped?.verified===true&&scoped.eye===report.eye&&scoped.visit===report.visit&&scoped.coordinate_system==='viewer_xy_mm'&&[scoped.x_mm,scoped.y_mm].every(finite)&&Math.hypot(scoped.x_mm,scoped.y_mm)<=radius)
  return {x:scoped.x_mm,y:scoped.y_mm,label:'Verified reported thinnest location',source:'reported'};
 const c=result?.case,l=c?.landmarks;
 if(c?.eye===report?.eye&&c.verified===true&&c.mode==='baseline'&&report?.visit==='first'&&l&&[l.thin_x,l.thin_y].every(finite)&&Math.hypot(l.thin_x,l.thin_y)<=radius)
  return {x:l.thin_x,y:l.thin_y,label:'Verified imported thinnest location',source:'reported'};
 return null;
}
function build(source,report,result){
 if(!source||source.nx<2||source.ny<2)return null;
 const xs=source.axisX,ys=source.axisY,w=xs.length,h=ys.length,r=source.radius||4.5;
 const R=finite(source.bfs)&&source.bfs>r?source.bfs:Math.max(7.8,r+.5);
 const sphere=(x,y)=>Math.sqrt(Math.max(.01,R*R-x*x-y*y))-R;
 const original=source.vertices;
 const residual=original.map((v,k)=>v?.front&&finite(v.front[2])?v.front[2]-sphere(xs[k%w],ys[Math.floor(k/w)]):null);
 const frontFit=complete(residual,w,h,0),thicknessFit=complete(original.map(v=>finite(v?.thickness)&&v.thickness>0?v.thickness:null),w,h,550);
 const z=Array.from(frontFit.values,(v,k)=>sphere(xs[k%w],ys[Math.floor(k/w)])+v);
 // Native back coordinates remain independent. Derived boundaries are never
 // described as native posterior heights.
 const backFits=source.kind==='native'&&original.some(v=>v?.back)?[0,1,2].map(axis=>complete(original.map(v=>finite(v?.back?.[axis])?v.back[axis]:null),w,h,0)):null;
 const minimum=M.findThinnest(source),verifiedC=cFor(result,report?.eye,report?.visit);
 const landmark=landmarkFor(report,result,r),selection=landmark||(minimum?{x:minimum.x,y:minimum.y,label:source.kind==='native'?'Lowest available mapped thickness':'Lowest reconstructed thickness',source:'reconstruction'}:{x:0,y:0,label:'Center · minimum unavailable',source:'center'});
 const prepared=C.prepare(source),maps={};
 for(const f of F){const direct=C.getMapField(prepared,f,false),local=C.getMapField(prepared,f,true);if(!direct)continue;
  const anchors=direct.values.map((v,k)=>[1,2].includes(direct.status[k])&&finite(v)?v:direct.status[k]===3&&finite(direct.previewValues?.[k])?direct.previewValues[k]:null);
  if(!anchors.some(finite))continue;
  const filled=complete(anchors,direct.width,direct.height,0);
  maps[f]={direct,local,visual:filled.values,range:direct.range,completionMask:Uint8Array.from(direct.status,v=>v===1?0:1)};
 }
 const limbus=Math.max(5.75,r+.4);
 function front(x,y){const rad=Math.hypot(x,y);if(rad<=r)return [x,y,sample(z,xs,ys,x,y)];
  const xx=x*r/rad,yy=y*r/rad,edge=sample(z,xs,ys,xx,yy)-sphere(xx,yy),t=clamp((rad-r)/(limbus-r),0,1),fade=1-t*t*(3-2*t);
  return [x,y,sphere(x,y)+edge*fade];
 }
 function normal(x,y){const d=.025;return unit([-(front(x+d,y)[2]-front(x-d,y)[2])/(2*d),-(front(x,y+d)[2]-front(x,y-d)[2])/(2*d),1]);}
 function back(x,y){if(backFits&&Math.hypot(x,y)<=r)return backFits.map(f=>sample(f.values,xs,ys,x,y));const p=front(x,y),n=normal(x,y),t=clamp(sample(thicknessFit.values,xs,ys,x,y),100,1500)/1000;return p.map((v,k)=>v-t*n[k]);}
 function geometrySupported(x,y){if(source.hasPatientGeometry===false||source.kind==='reference'||Math.hypot(x,y)>r)return false;return neighbors(xs,ys,x,y).every(([k])=>original[k]?.front&&original[k].provenance!=='filled'&&original[k].provenance!=='reference');}
 function backSupported(x,y){if(source.hasPatientGeometry===false||source.kind==='reference'||Math.hypot(x,y)>r)return false;return neighbors(xs,ys,x,y).every(([k])=>original[k]?.back?.every(finite));}
 function reading(f,x,y){const m=maps[f];if(!m||Math.hypot(x,y)>r)return {value:null,origin:'Unavailable',kind:'unavailable'};
  const raw=C.sample(m.direct,x,y),near=C.sample(m.local,x,y);
  if(raw?.status===1&&finite(raw.value))return {value:f==='posterior'?Math.abs(raw.value):raw.value,kind:'source',origin:source.kind==='native'?'Device map sample':'Decoded report color'};
  if(near?.status===2&&finite(near.value))return {value:f==='posterior'?Math.abs(near.value):near.value,kind:'estimate',origin:'Local visual estimate'};
  const st=C.sampleStatus(m.direct,x,y);return {value:null,kind:'unavailable',origin:st?.status===3?'Color limit / uncertain':'Visual completion only'};
 }
 function reconstructionThickness(x,y){if(Math.hypot(x,y)>r)return null;const ns=neighbors(xs,ys,x,y);return ns.every(([k])=>finite(original[k]?.thickness))?ns.reduce((a,[k,p])=>a+original[k].thickness*p,0):null;}
 function visual(f,x,y){const m=maps[f];return m?sample(m.visual,m.direct.axisX,m.direct.axisY,x,y):null;}
 return {source,report,result,radius:r,limbus,bfs:R,maps,minimum,verifiedC,selection,front,back,normal,geometrySupported,backSupported,reading,visual,reconstructionThickness,
  delta:verifiedC&&minimum?minimum.thickness-verifiedC.value:null,
  hasPatientGeometry:source.hasPatientGeometry!==false&&source.kind!=='reference',
  innerKind:backFits?'Supplied posterior coordinates':thicknessFit.count?'Thickness-derived inner boundary':'Reference inner boundary · thickness unavailable',
  geometryStatus:frontFit.count?'Supported coordinates plus display-only completion':'Reference geometry only'};
}
function mesh(model){
 const nr=40,na=120,points=[model.front(0,0)],normals=[model.normal(0,0)],triangles=[];
 for(let j=1;j<=nr;j++)for(let i=0;i<na;i++){const a=2*Math.PI*i/na,r=model.limbus*j/nr,x=r*Math.cos(a),y=r*Math.sin(a);points.push(model.front(x,y));normals.push(model.normal(x,y));}
 for(let i=0;i<na;i++)triangles.push([0,1+i,1+(i+1)%na]);
 for(let j=2;j<=nr;j++)for(let i=0;i<na;i++){const a=1+(j-2)*na+i,b=1+(j-2)*na+(i+1)%na,c=a+na,d=b+na;triangles.push([a,c,d],[a,d,b]);}
 const back=points.map(p=>model.back(p[0],p[1])),closed=[...triangles,...triangles.map(a=>a.map(i=>i+points.length).reverse())],start=1+(nr-1)*na;
 for(let i=0;i<na;i++){const a=start+i,b=start+(i+1)%na;closed.push([a,b,a+points.length],[b,b+points.length,a+points.length]);}
 return {points,normals,triangles,back,closed};
}
const api={complete,sample,neighbors,cFor,landmarkFor,build,mesh,F};if(node)module.exports=api;else root.NKPIContinuousReview=api;
})(typeof window!=='undefined'?window:globalThis);
