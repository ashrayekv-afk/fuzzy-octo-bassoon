/* Local, dependency-free Streamlit v1 bootstrap. No inputs, files or identifiers logged. */
(function () {
  'use strict';
  let started = false, connected = false, failed = false, latestRender = null;
  let readySent = false;
  const parentWindow = window.parent;
  function post(type, extra) {
    parentWindow.postMessage(Object.assign({isStreamlitMessage: true, type: type}, extra || {}), '*');
  }
  function status(text, isError) {
    let panel = document.getElementById('nkpi-startup-status');
    if (!panel && document.body) {
      panel = document.createElement('div');
      panel.id = 'nkpi-startup-status';
      panel.setAttribute('role', isError ? 'alert' : 'status');
      panel.style.cssText = 'margin:12px;padding:14px;border:1px solid #c9b6dc;border-radius:10px;background:#f7f3fc;color:#31203f;font:14px system-ui;';
      document.body.prepend(panel);
    }
    if (panel) { panel.textContent = text; panel.hidden = false; }
  }
  function fail() {
    if (connected) return;
    failed = true;
    status('The full interface could not finish loading. Select “Basic calculator (loading recovery)” above this panel to use the same frozen NKPI models. Reboot the app after replacing both release files.', true);
    post('streamlit:setFrameHeight', {height: Math.max(300, document.body ? document.body.scrollHeight : 300)});
  }
  function announce() {
    if (readySent || parentWindow === window) return;
    readySent = true;
    post('streamlit:componentReady', {apiVersion: 1});
    post('streamlit:setFrameHeight', {height: 800});
  }
  window.addEventListener('message', function (event) {
    if (event.source === parentWindow && event.data && event.data.type === 'streamlit:render') {
      latestRender = {data: event.data, source: event.source, origin: event.origin};
    }
  });
  window.addEventListener('error', function (event) {
    // Do not expose exception messages or data. A missing optional extractor resource
    // does not disable manual entry once the main application has started.
    if (!started && (!event.target || event.target === window || event.target.tagName === 'SCRIPT')) fail();
  }, true);
  window.addEventListener('unhandledrejection', function () { if (!started) fail(); });
  const deadline = window.setTimeout(function () { if (!connected) fail(); }, 12000);
  window.NKPIStartup = Object.freeze({
    applicationReady: function () {
      started = true;
      announce();
      // The parent may have sent config before app.js registered its listener.
      // Replay that one render after initialization, with its original source.
      if (latestRender) window.dispatchEvent(new MessageEvent('message', latestRender));
    },
    modelReady: function () {
      connected = true; failed = false;
      window.clearTimeout(deadline);
      const panel = document.getElementById('nkpi-startup-status');
      if (panel) panel.hidden = true;
    }
  });
  document.addEventListener('DOMContentLoaded', function () {
    if (failed) fail();
    else if (!connected) status('Loading the local interface and verified NKPI models…', false);
  });
  announce();
})();
