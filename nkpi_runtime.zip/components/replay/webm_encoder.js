/* Local, deterministic VP8/WebM writer. Each canvas frame is encoded as a WebP
 * VP8 keyframe, then timed in WebM. No dropped screen-refresh frames, uploads,
 * microphone/camera access, dependencies, or raw image-frame accumulation.
 * Container: https://www.webmproject.org/docs/container/ */
(function(root){'use strict';
const encoder=new TextEncoder();let support=null;
const concat=parts=>{const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;};
function bytes(n){if(!Number.isSafeInteger(n)||n<0)throw Error('Invalid EBML integer.');const a=[];do{a.unshift(n%256);n=Math.floor(n/256);}while(n);return Uint8Array.from(a);}
function size(n){for(let w=1;w<=8;w++)if(n<2**(7*w)-1){const a=new Uint8Array(w);for(let i=w-1;i>=0;i--){a[i]=n%256;n=Math.floor(n/256);}a[0]|=1<<(8-w);return a;}throw Error('Video exceeds container size limit.');}
function element(id,data){return concat([bytes(id),size(data.length),data]);}
const uint=(id,n)=>element(id,bytes(n)),str=(id,s)=>element(id,encoder.encode(s)),master=(id,children)=>element(id,concat(children));
function float(id,n){const b=new Uint8Array(8);new DataView(b.buffer).setFloat64(0,n,false);return element(id,b);}
function parseVP8(data,width,height){const b=data instanceof Uint8Array?data:new Uint8Array(data),tag=(i,n)=>String.fromCharCode(...b.subarray(i,i+n));
 if(b.length<20||tag(0,4)!=='RIFF'||tag(8,4)!=='WEBP')throw Error('This browser cannot encode WebP for deterministic video. Use GIF.');
 for(let i=12;i+8<=b.length;){const n=new DataView(b.buffer,b.byteOffset+i+4,4).getUint32(0,true),type=tag(i,4);if(i+8+n>b.length)throw Error('Truncated WebP frame.');
  if(type==='VP8 '){const v=b.slice(i+8,i+8+n);if(v.length<10||(v[0]&1)||v[3]!==0x9d||v[4]!==1||v[5]!==0x2a)throw Error('VP8 keyframe missing.');
   if(((v[6]|v[7]<<8)&0x3fff)!==width||((v[8]|v[9]<<8)&0x3fff)!==height)throw Error('Video frame dimensions do not match.');return v;}
  i+=8+n+(n&1);
 }throw Error('Browser returned a WebP variant without a VP8 keyframe. Use GIF.');
}
function supported(){if(support!==null)return support;if(typeof document==='undefined')return false;try{const c=document.createElement('canvas');c.width=c.height=2;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,2,2);support=c.toDataURL('image/webp',.85).startsWith('data:image/webp');}catch(_){support=false;}return support;}
async function encode({canvas,count,fps=30,drawFrame,signal,onProgress=()=>{},quality=.90}={}){
 const width=canvas?.width,height=canvas?.height;
 if(!Number.isInteger(count)||count<2||count>900||!Number.isFinite(fps)||fps<1||fps>60||!width||!height||width>1600||height>1200||typeof drawFrame!=='function')throw Error('Invalid video request.');
 const check=()=>{if(signal?.aborted)throw Error('Video export canceled.');};check();
 const header=master(0x1a45dfa3,[uint(0x4286,1),uint(0x42f7,1),uint(0x42f2,4),uint(0x42f3,8),str(0x4282,'webm'),uint(0x4287,2),uint(0x4285,2)]);
 const info=master(0x1549a966,[uint(0x2ad7b1,1000000),float(0x4489,count*1000/fps),str(0x4d80,'NKPI local deterministic replay'),str(0x5741,'NKPI 9.2.1')]);
 const tracks=master(0x1654ae6b,[master(0xae,[uint(0xd7,1),uint(0x73c5,1),uint(0x83,1),uint(0x9c,0),str(0x86,'V_VP8'),uint(0x23e383,Math.round(1e9/fps)),master(0xe0,[uint(0xb0,width),uint(0xba,height)])])]);
 const clusters=[];let blocks=[],base=0,total=0;
 function flush(){if(blocks.length){const c=master(0x1f43b675,[uint(0xe7,base),...blocks]);clusters.push(c);total+=c.length;blocks=[];}}
 for(let i=0;i<count;i++){check();await drawFrame(i,count);check();
  const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Browser frame encoder returned no data.')),'image/webp',quality));check();
  const frame=parseVP8(new Uint8Array(await blob.arrayBuffer()),width,height),ms=Math.round(i*1000/fps);
  if(blocks.length&&ms-base>=1000){flush();base=ms;}
  const relative=ms-base;if(relative>32767)throw Error('Video timestamp exceeds cluster limit.');
  blocks.push(element(0xa3,concat([Uint8Array.from([0x81,(relative>>8)&255,relative&255,0x80]),frame])));
  if(total>180*1024*1024)throw Error('Video is too large. Choose a shorter clip or use GIF.');
  onProgress((i+1)/count);await new Promise(r=>setTimeout(r,0));
 }check();flush();const parts=[info,tracks,...clusters],length=parts.reduce((n,p)=>n+p.length,0);
 return new Blob([header,bytes(0x18538067),size(length),...parts],{type:'video/webm'});
}
const api={encode,supported,parseVP8,bytes,size,element};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIReplayVideo=api;
})(typeof window!=='undefined'?window:globalThis);
