/* Continuous corneal replay 9.2.1. Only replay presentation/export changes.
 * OCR, sources, clinical inputs, model calculations and primary viewer are read-only. */
(function(root){'use strict';
const EYES=['OD','OS'],FIELDS=['thickness','anterior','posterior'],W=1100,H=720,EW=510,EH=360;
const LABEL={shape:'Natural corneal surface',thickness:'Thickness',anterior:'Anterior curvature',posterior:'Posterior curvature |D|'};
const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),fmt=(v,d=2)=>finite(v)?v.toFixed(d):'—';
const signed=(v,d=2)=>finite(v)?(v>0?'+':v<0?'−':'')+Math.abs(v).toFixed(d):'—';
const wait=()=>new Promise(r=>setTimeout(r,0));
function mount(host,setsByEye={},results={},options={}){
 if(!host)return ()=>{};
 const X=root.NKPIReplayMath,F=root.NKPIFluidRenderer,R=root.NKPIContinuousReview,I=root.NKPIIntegratedModel,M=root.NKPIIntegratedMeasurements;
 if(!X||!F||!R||!I||!M){host.textContent='Replay files are unavailable. Restore the complete release package.';return ()=>{};}
 const pairs={},obs={},models={},renderers={},scales={},offs=[],urls=new Set();
 for(const eye of EYES){obs[eye]=X.observations(results[eye],eye);pairs[eye]=obs[eye]?X.reportPair(setsByEye[eye],eye):null;}
 const eligible=EYES.filter(e=>pairs[e]);
 const state={mode:'smooth',field:'shape',view:'oblique',gain:1,support:false,outline:true,duration:10,loop:true,t:0,...options.initialState};
 if(!['smooth','snapshots'].includes(state.mode))state.mode='smooth';if(!['shape',...FIELDS].includes(state.field))state.field='shape';if(!['oblique','front','profile'].includes(state.view))state.view='oblique';
 state.gain=[1,3,5,10].includes(+state.gain)?+state.gain:1;state.duration=[4,6,10,15].includes(+state.duration)?+state.duration:10;state.t=0;
 let dead=false,generation=0,busy=false,prepared=false,playing=false,raf=null,lastTime=null,position=0,projection=null,exportAbort=null,recording=null,stream=null,previewURL=null;
 let drawCount=0,lastFraction=null,fractionChanges=0,fpsTicks=0,fpsStart=null,fps=0;
 const q=s=>host.querySelector(s),all=s=>[...host.querySelectorAll(s)];
 function metricHTML(eye){const o=obs[eye];if(!o)return `<article class="rp-rates"><h4>${eye} · Rate unavailable</h4><p>Two verified examinations and a positive interval are required.</p></article>`;
  return `<article class="rp-rates"><h4>${eye} · ${fmt(o.days,0)} days observed</h4><div class="rp-tablewrap"><table><thead><tr><th>Measurement</th><th>Baseline</th><th>Latest</th><th>Change</th><th>Per year*</th></tr></thead><tbody>${o.rows.map(m=>`<tr><th>${m.label}${m.unit?' ('+m.unit+')':''}</th><td>${fmt(m.first,m.decimals)}</td><td>${fmt(m.latest,m.decimals)}</td><td>${signed(m.delta,m.decimals)}</td><td>${signed(m.rate,m.id==='C'?1:2)}</td></tr>`).join('')}</tbody></table></div><p>*Observed change × 365.25 / elapsed days. Not a forecast.${o.shortInterval?' Short intervals amplify measurement variability.':''}</p></article>`;}
 host.innerHTML=`<section class="rp-root" aria-label="Continuous corneal progression replay"><header class="rp-heading"><div><span class="rp-eyebrow">CORNEAL PROGRESSION REPLAY · CONTINUOUS SURFACE</span><h3>Watch the surface change.</h3><p>A close-up of baseline → latest, with the camera held still.</p></div><span class="rp-pill">9.2.1 · Fluid replay</span></header>
 <p class="rp-notice">Only the two scan endpoints were observed. Motion between them is an <strong>illustrated transition</strong>, not measured tissue motion, a prediction, or proof of progression.</p>
 <div class="rp-transport rp-transport-top"><button data-rp-prepare ${eligible.length?'':'disabled'}>Prepare &amp; play</button><button data-rp-play disabled>▶ Play</button><button data-rp-first disabled>Baseline</button><input data-rp-scrub type="range" min="0" max="10000" step="1" value="0" aria-label="Illustrated transition position" disabled><button data-rp-last disabled>Latest</button><output data-rp-progress>0%</output></div>
 <div class="rp-controls"><label>Playback<select data-rp-mode><option value="smooth">Continuous surface animation</option><option value="snapshots">Endpoint comparison only</option></select></label><label>Surface color<select data-rp-field>${['shape',...FIELDS].map(f=>`<option value="${f}">${LABEL[f]}</option>`).join('')}</select></label><label>Camera<select data-rp-view><option value="oblique">3D cornea close-up</option><option value="profile">Side profile / cone</option><option value="front">Front / maps</option></select></label><label>Change visibility<select data-rp-gain><option value="1">Actual display scale ×1</option><option value="3">Magnify change ×3</option><option value="5">Magnify change ×5</option><option value="10">Magnify change ×10</option></select></label><label>Clip length<select data-rp-duration><option value="4">4 seconds</option><option value="6">6 seconds</option><option value="10">10 seconds</option><option value="15">15 seconds</option></select></label></div>
 <div class="rp-toggles"><label><input type="checkbox" data-rp-outline checked> Fixed baseline outline</label><label><input type="checkbox" data-rp-support> Show shared source support</label><label><input type="checkbox" data-rp-loop checked> Loop</label><span data-rp-engine>Continuous geometry · no image cross-fade</span></div>
 <p class="rp-gain-notice" data-rp-gain-notice hidden>DISPLAY CHANGE MAGNIFIED: this is not actual anatomy. Measured values and map colors are not magnified.</p>
 <div class="rp-player"><canvas data-rp-canvas width="1100" height="720" role="img" aria-label="Fluid corneal surface transition, right and left eye"></canvas><div class="rp-live-surfaces" data-rp-surfaces aria-hidden="true"></div><canvas class="rp-live-guides" data-rp-guides width="1100" height="720" aria-hidden="true"></canvas></div>
 <p class="rp-status" data-rp-status role="status">${eligible.length?'Press Prepare & play. Replay starts after calculation and adds no OCR work.':'Import, verify and calculate two visits first. Scalar numbers alone cannot create a moving cornea.'}</p>
 <div class="rp-exports"><button data-rp-video disabled>Save smooth video</button><button data-rp-gif disabled>Save animated GIF</button><button data-rp-png disabled>Save still</button><button data-rp-cancel hidden>Cancel</button><span data-rp-export-note>Local export · complete 30 fps movie; 20 fps GIF</span></div>
 <div class="rp-video-preview" data-rp-preview hidden><h4>Your exported movie</h4><video data-rp-preview-video controls muted loop playsinline></video><p>Illustrated transition. No extra measured examinations are implied.</p></div>
 <div class="rp-rategrid">${EYES.map(metricHTML).join('')}</div>
 <details class="rp-method"><summary>Display scale, source support and limitations</summary><p>The surface is re-rendered during playback; it is not a sequence of cached endpoint pictures. Shared source-supported coordinates are interpolated between the two reconstructed examinations. Playback timing is presentation speed, not a measurement of biological motion. Clinical progression may be nonlinear or interrupted by treatment.</p><p>Gray areas are fixed baseline/reference geometry, not measured moving tissue. Unsupported regions do not acquire motion. Different coordinate grids or reconstruction types prevent interpolation for that eye. Matching display coordinates are not proof of anatomical registration. The inner boundary may be thickness-derived. Scalar C cannot localize thinning and does not create geometry.</p><p>At ×1, physical axes have equal scale and display differences are not enlarged. Magnified change applies only to the difference from baseline in supported display coordinates. ×3, ×5 and ×10 are visual aids, not actual corneal anatomy; they never change measured numbers, map values, NKPI, or uncertainty. Do not use the magnified view for dimensions or surgical planning.</p><p>Color scales are fixed across compatible endpoints. Only direct map support is colored; missing or incompatible maps are not invented. Reconstructed surfaces and any color decoding remain approximate where image-derived. Fixed baseline outlines are display-coordinate guides, not measured tissue-displacement vectors.</p><p>Only baseline and latest are supported in this release. Verify source accuracy, repeatability, contact lens conditions and treatment history before interpreting change. No statistical confidence interval, acceleration claim or treatment recommendation is generated. Exported files may still be sensitive clinical information; store and share under approved arrangements.</p></details></section>`;
 const canvas=q('[data-rp-canvas]'),mainCtx=canvas.getContext('2d'),live=q('[data-rp-surfaces]'),guides=q('[data-rp-guides]'),guideCtx=guides.getContext('2d');let ctx=mainCtx;
 const on=(el,type,fn)=>{el.addEventListener(type,fn);offs.push(()=>el.removeEventListener(type,fn));};
 const status=t=>{if(!dead)q('[data-rp-status]').textContent=t;};
 function stop(){playing=false;if(raf!==null)cancelAnimationFrame(raf);raf=null;lastTime=null;if(!dead)q('[data-rp-play]').textContent='▶ Play';}
 function release(){for(const eye of EYES){renderers[eye]?.dispose();delete renderers[eye];}live.replaceChildren();}
 function previewClear(){const v=q('[data-rp-preview-video]');v.pause();v.removeAttribute('src');v.load();q('[data-rp-preview]').hidden=true;if(previewURL){URL.revokeObjectURL(previewURL);urls.delete(previewURL);previewURL=null;}}
 function save(blob,name,preview=false){if(dead)return;const u=URL.createObjectURL(blob);urls.add(u);const a=document.createElement('a');a.href=u;a.download=name;a.click();if(preview){previewClear();previewURL=u;const v=q('[data-rp-preview-video]');v.src=u;q('[data-rp-preview]').hidden=false;v.play().catch(()=>{});}else setTimeout(()=>{URL.revokeObjectURL(u);urls.delete(u);},60000);}
 function videoType(){if(!root.MediaRecorder||!canvas.captureStream)return null;for(const type of ['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm','video/mp4'])if(root.MediaRecorder.isTypeSupported(type))return type;return null;}
 function setControls(){if(dead)return;for(const k of ['mode','field','view','gain','duration'])q('[data-rp-'+k+']').value=state[k];for(const k of ['support','outline','loop'])q('[data-rp-'+k+']').checked=state[k];
  for(const k of ['play','first','last','scrub','gif','png'])q('[data-rp-'+k+']').disabled=!prepared||busy;
  q('[data-rp-video]').disabled=!prepared||busy||!(root.NKPIReplayVideo?.supported()||videoType());q('[data-rp-prepare]').disabled=busy||!eligible.length;q('[data-rp-prepare]').textContent=prepared?'Rebuild & play':'Prepare & play';
  for(const el of all('select,[data-rp-outline],[data-rp-support],[data-rp-loop]'))el.disabled=busy;
  q('[data-rp-gain]').disabled=busy||state.mode==='snapshots';q('[data-rp-cancel]').hidden=!busy;
  q('[data-rp-gain-notice]').hidden=state.gain===1||state.mode==='snapshots';
  q('[data-rp-play]').textContent=playing?'❚❚ Pause':'▶ Play';q('[data-rp-export-note]').textContent=root.NKPIReplayVideo?.supported()?'Local export · complete 30 fps movie; 20 fps GIF':'Local export · 20 fps GIF; browser video recording rate varies';
 }
 function findScales(){for(const e of EYES)scales[e]={};for(const f of FIELDS){const groups=new Map();for(const e of eligible){const p=models[e];if(!p?.first?.maps[f]||!p.latest?.maps[f])continue;const a=M.rangeSignature(p.first.source,f),b=M.rangeSignature(p.latest.source,f);if(a!==b)continue;const g=groups.get(a)||{eyes:[],min:Infinity,max:-Infinity};g.eyes.push(e);for(const model of [p.first,p.latest]){const d=model.maps[f].direct;for(let i=0;i<d.values.length;i++)if(d.status[i]===1&&finite(d.values[i])){const v=f==='posterior'?Math.abs(d.values[i]):d.values[i];g.min=Math.min(g.min,v);g.max=Math.max(g.max,v);}}groups.set(a,g);}for(const g of groups.values())if(finite(g.min)&&finite(g.max)){const s=M.makeScale(f,{min:g.min,max:g.max});for(const e of g.eyes)scales[e][f]=s;}}
 }
 function updateProjection(){projection=F.projection(Object.values(renderers).map(r=>r.geometry),state.view,EW,EH,state.mode==='snapshots'?1:state.gain);}
 function setField(){for(const e of EYES)renderers[e]?.setField(scales[e]?.[state.field]?state.field:'shape',scales[e]?.[state.field]||null);}
 function text(s,x,y,size=16,color='#e0e9f3',align='left'){ctx.font=size+'px Arial';ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(s,x,y);ctx.textAlign='left';}
 function guide(model,target,t,x,y,base=false){if(!projection||!model)return;ctx.save();ctx.translate(x,y);ctx.strokeStyle=base?'#e8bfff':'#d1faf8';ctx.lineWidth=base?1.6:1.15;ctx.setLineDash(base?[5,5]:[]);ctx.beginPath();let start=false;
  const radius=Math.min(model.radius,target.radius)*.94,xx=clamp(model.selection?.x||0,-radius*.7,radius*.7),limit=Math.sqrt(radius**2-xx**2);ctx.beginPath();ctx.rect(0,0,EW,EH);ctx.clip();ctx.beginPath();
  for(let yy=-limit;yy<=limit;yy+=.035){if(!model.geometrySupported(xx,yy)||!target.geometrySupported(xx,yy)){start=false;continue;}const p=base?model.front(xx,yy):F.pose(model.front(xx,yy),target.front(xx,yy),t,state.mode==='snapshots'?1:state.gain,true);const q=F.project(p,projection);if(start)ctx.lineTo(q[0],q[1]);else ctx.moveTo(q[0],q[1]);start=true;}ctx.stroke();ctx.restore();}
 function legend(scale,x,y,width){if(!scale)return;const gradient=ctx.createLinearGradient(x,0,x+width,0);scale.stops.forEach((c,i)=>gradient.addColorStop(i/4,'rgb('+c.map(v=>Math.round(v*255)).join(',')+')'));ctx.fillStyle=gradient;ctx.fillRect(x,y,width,8);text(fmt(scale.min,state.field==='thickness'?0:1),x,y+24,10);text(fmt(scale.max,state.field==='thickness'?0:1)+(state.field==='thickness'?' µm':' D'),x+width,y+24,10,'#e0e9f3','right');}
 function compose(t,capture=false){if(dead)return;ctx=mainCtx;guideCtx.clearRect(0,0,W,H);live.hidden=capture;guides.hidden=capture;state.t=clamp(t,0,1);drawCount++;if(lastFraction!==state.t){fractionChanges++;lastFraction=state.t;}
  ctx.fillStyle='#0b1422';ctx.fillRect(0,0,W,H);text('CORNEAL PROGRESSION REPLAY',26,34,23);text(options.syntheticLabel?'SYNTHETIC ENGINEERING EXAMPLE · NOT PATIENT DATA':'Continuously rendered surface · fixed camera · two observed endpoints',26,58,12,'#aabbd1');
  const gain=state.mode==='snapshots'?1:state.gain;
  text(gain===1?'ACTUAL DISPLAY SCALE ×1':'CHANGE MAGNIFIED ×'+gain+' · NOT ACTUAL ANATOMY',W-25,34,12,gain===1?'#9edfd5':'#ffd397','right');
  ctx.fillStyle='#45315e';ctx.fillRect(25,76,W-50,32);
  let label=state.t===0?'BASELINE · comparable scan reconstruction':state.t===1?'LATEST · comparable scan reconstruction':'ILLUSTRATED TRANSITION · '+Math.round(state.t*100)+'% · not a measured scan';
  if(gain>1)label=(state.t===0?'BASELINE reference':'ILLUSTRATED TARGET · '+Math.round(state.t*100)+'%')+' · change ×'+gain+' is exaggerated, not actual anatomy';text(label,37,98,13);
  for(let i=0;i<2;i++){const eye=EYES[i],x=25+i*540,y=153,p=models[eye],renderer=renderers[eye],o=obs[eye];
   text(eye+' · '+(eye==='OD'?'Right eye':'Left eye'),x,135,17);text(o?fmt(o.days,0)+' days observed':'Two visits required',x+EW,135,12,'#b6c4d5','right');
   ctx.fillStyle='#101d30';ctx.fillRect(x,y,EW,EH);
   if(renderer&&projection){const u=state.mode==='snapshots'?(state.t<.5?0:1):state.t;const success=renderer.draw(u,{gain,support:state.support,projection});
    if(success){if(capture)ctx.drawImage(renderer.canvas,x,y,EW,EH);if(state.outline&&p.compat.ok){ctx=capture?mainCtx:guideCtx;guide(p.first,p.latest,u,x,y,true);if(state.view!=='front')guide(p.first,p.latest,u,x,y,false);ctx=mainCtx;}}
    else text('Graphics context unavailable. Rebuild replay.',x+EW/2,y+EH/2,13,'#ffcdaf','center');
   }else{const message=busy?'Preparing paired surfaces…':p?.error?'Continuous shape unavailable':'Prepare & play to start';text(message,x+EW/2,y+EH/2,15,'#bfcce0','center');}
   text('Dashed purple: baseline · gray: fixed / unsupported',x,y+EH+19,11,'#cbbada');
   if(p?.error){text(p.error.length>78?p.error.slice(0,75)+'…':p.error,x,y+EH+37,10,'#ffcdaf');}
   else text(p?.first?.source.kind==='native'?'Supplied coordinates; anatomical registration unverified':'Image-derived reconstruction · approximate, not anatomical validation',x,y+EH+37,10,'#aebbd0');
   if(state.field!=='shape'&&scales[eye]?.[state.field]){ctx=capture?mainCtx:guideCtx;legend(scales[eye][state.field],x+12,y+EH-40,EW-24);ctx=mainCtx;}
   const C=o?.rows.find(r=>r.id==='C'),K=o?.rows.find(r=>r.id==='Kmax');
   text('C  '+fmt(C?.first,0)+' → '+fmt(C?.latest,0)+' µm',x,578,16);text('Kmax  '+fmt(K?.first,2)+' → '+fmt(K?.latest,2)+' D',x+265,578,16);
   text('Observed '+signed(C?.rate,1)+' µm/year',x,600,12,'#becae0');text('Observed '+signed(K?.rate,2)+' D/year',x+265,600,12,'#becae0');
  }
  const left=35,right=W-35,ty=638;ctx.fillStyle='#25344e';ctx.fillRect(left,ty,right-left,6);ctx.fillStyle='#ad89dd';ctx.fillRect(left,ty,(right-left)*state.t,6);ctx.beginPath();ctx.arc(left+(right-left)*state.t,ty+3,7,0,2*Math.PI);ctx.fillStyle='#dfc9ff';ctx.fill();text('Baseline scan',left,665,12);text('Latest scan',right,665,12,'#e0e9f3','right');
  text('INTERMEDIATE FRAMES ARE ILLUSTRATIONS · No forecast or acceleration claim · Verify scan quality and treatment history.',25,692,11,'#c2ccdb');
  text(gain===1?'Equal physical axes. Only shared source support moves; fixed reference regions are gray.':'VISUAL DIFFERENCE ×'+gain+' ONLY. Actual measurements, map values and NKPI are unchanged.',25,710,10,gain===1?'#91a5bc':'#ffd397');
  q('[data-rp-scrub]').value=Math.round(state.t*10000);q('[data-rp-progress]').value=Math.round(state.t*100)+'%';
 }
 async function prepare(autoPlay=true){stop();previewClear();const token=++generation;busy=true;prepared=false;release();setControls();compose(0);status('Preparing endpoint geometry once. No OCR or measurement extraction is running.');
  try{for(const e of eligible){await wait();if(dead||token!==generation)return;try{if(!models[e]){const a=I.fromReport(pairs[e].first),b=I.fromReport(pairs[e].latest),first=R.build(a,pairs[e].first,results[e]),latest=R.build(b,pairs[e].latest,results[e]);if(!first||!latest)throw Error('Paired source geometry is unavailable.');const compat=X.geometryCompatibility(first,latest);models[e]={first,latest,compat};}
     const p=models[e];if(!p.compat.ok)throw Error(p.compat.reason);const geometry=F.buildGeometry(p.first,p.latest,{rings:options.forceCanvas?13:24,sectors:options.forceCanvas?64:96});
     const c=document.createElement('canvas');c.width=EW;c.height=EH;renderers[e]=F.create(c,geometry,p.first,p.latest,{forceCanvas:options.forceCanvas===true,forceWebGL:options.forceWebGL===true,onFailure:message=>{stop();status(message);}});
     const visible=renderers[e].canvas;visible.className='rp-live-eye';visible.style.cssText='position:absolute;left:'+((25+EYES.indexOf(e)*540)/W*100)+'%;top:'+(153/H*100)+'%;width:'+(EW/W*100)+'%;height:'+(EH/H*100)+'%;aspect-ratio:auto;';live.append(visible);delete p.error;
    }catch(error){models[e]??={};models[e].error=String(error.message||error);}}
   if(dead||token!==generation)return;findScales();prepared=EYES.some(e=>renderers[e]);if(!prepared)throw Error('No compatible paired spatial data. The numerical changes below remain available.');
   updateProjection();setField();for(const f of FIELDS)q('[data-rp-field] option[value="'+f+'"]').disabled=!eligible.some(e=>scales[e]?.[f]);
   position=0;status('Ready. The corneal surface moves continuously; only the endpoints are observed. Gray reference regions stay fixed.');
  }catch(e){status('Replay unavailable: '+e.message+' The calculator and extractor have not changed.');}
  finally{if(!dead&&token===generation){busy=false;setControls();compose(0);if(prepared&&autoPlay!==false&&!root.matchMedia?.('(prefers-reduced-motion: reduce)').matches)play();}}
 }
 function tick(now){if(dead||!playing||busy)return;if(lastTime!==null)position+=(now-lastTime)/(state.duration*1000);lastTime=now;
  if(position>=1){compose(1);if(!state.loop){position=1;stop();status('Latest reconstruction reached. Press Play to start again.');return;}position=0;status('Loop restarted at baseline. This is replay, not reverse biological change.');}
  const t=state.mode==='smooth'?F.phase(position):(position<.5?0:1);compose(t);if(fpsStart===null)fpsStart=now;fpsTicks++;if(now-fpsStart>1000){fps=Math.round(fpsTicks*1000/(now-fpsStart));fpsTicks=0;fpsStart=now;q('[data-rp-engine]').textContent='Continuous geometry · '+fps+' fps on this browser';}raf=requestAnimationFrame(tick);
 }
 function play(){if(playing){stop();return;}if(!prepared||busy)return;if(position>=1)position=0;playing=true;lastTime=null;fpsStart=null;fpsTicks=0;setControls();raf=requestAnimationFrame(tick);}
 function seek(t){stop();position=t===0?0:t===1?1:.08+.84*t;compose(state.mode==='snapshots'?(t<.5?0:1):t);}
 function refresh(){if(!prepared){setControls();compose(0);return;}updateProjection();setField();setControls();compose(state.t);}
 function terminateRecording(){if(recording?.state!=='inactive')try{recording?.stop();}catch(_){}stream?.getTracks().forEach(t=>t.stop());recording=null;stream=null;}
 function cancel(){stop();generation++;exportAbort?.abort();exportAbort=null;terminateRecording();busy=false;if(!prepared)release();setControls();compose(state.t);status('Canceled. Existing verified measurements are unchanged.');}
 async function exportGIF(){if(!prepared||busy)return;stop();const token=++generation,abort=new AbortController();exportAbort=abort;busy=true;setControls();status('Creating fluid GIF locally. Frames are encoded one at a time.');
  const prev=state.t,c=document.createElement('canvas');c.width=880;c.height=576;const cctx=c.getContext('2d'),count=state.duration*20;
  function frame(i){if(dead||token!==generation||abort.signal.aborted)throw Error('GIF export canceled.');const p=i/(count-1),t=state.mode==='smooth'?F.phase(p):p<.5?0:1;compose(t,true);cctx.drawImage(canvas,0,0,c.width,c.height);return cctx.getImageData(0,0,c.width,c.height);}
  try{const samples=[0,.25,.5,.75,1].map(t=>frame(Math.round(t*(count-1))));
   const blob=await root.NKPIReplayGIF.encodeStream({count,width:c.width,height:c.height,frameAt:frame,paletteFrames:samples,delays:()=>5,signal:abort.signal,onProgress:p=>status('Encoding continuous GIF · '+Math.round(p*100)+'%')});
   if(dead||token!==generation)return;save(blob,'NKPI_continuous_transition_x'+(state.mode==='snapshots'?1:state.gain)+'.gif');status('Animated GIF saved with 20 frames per second and interpretation labels. Video is smoother where supported.');
  }catch(e){if(!dead&&token===generation)status('GIF not saved: '+e.message);}finally{c.width=c.height=1;if(!dead&&token===generation){busy=false;exportAbort=null;setControls();compose(prev);}}
 }
 async function exportVideoRealtime(){if(!prepared||busy||!videoType())return;stop();const token=++generation,abort=new AbortController();exportAbort=abort;busy=true;setControls();status('Recording a continuous movie locally. Keep this tab visible.');
  const prev=state.t;let chunks=[],jobRecorder,jobStream;
  try{compose(0,true);jobStream=stream=canvas.captureStream(30);const mime=videoType();jobRecorder=recording=new root.MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:5000000});
   const done=new Promise((resolve,reject)=>{jobRecorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};jobRecorder.onerror=()=>reject(Error('Browser encoder failed.'));jobRecorder.onstop=resolve;});done.catch(()=>{});
   jobRecorder.start(100);let began=null;
   await new Promise((resolve,reject)=>{function step(now){if(dead||token!==generation||abort.signal.aborted){reject(Error('Video export canceled.'));return;}if(began===null)began=now;const p=clamp((now-began)/(state.duration*1000),0,1);compose(state.mode==='smooth'?F.phase(p):(p<.5?0:1),true);if(p<1)requestAnimationFrame(step);else resolve();}requestAnimationFrame(step);});
   if(jobRecorder.state!=='inactive')jobRecorder.stop();let timer;await Promise.race([done,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Video encoder did not finish.')),5000);})]).finally(()=>clearTimeout(timer));
   if(dead||token!==generation||abort.signal.aborted)return;if(!chunks.length)throw Error('No movie data were created.');save(new Blob(chunks,{type:mime}),'NKPI_continuous_transition_x'+(state.mode==='snapshots'?1:state.gain)+(mime.includes('mp4')?'.mp4':'.webm'),true);status('Smooth video saved and opened below. It is an illustrated transition, not a recorded sequence of scans.');
  }catch(e){if(!dead&&token===generation)status('Video not saved: '+e.message);}finally{if(jobRecorder?.state!=='inactive')try{jobRecorder?.stop();}catch(_){}jobStream?.getTracks().forEach(t=>t.stop());if(recording===jobRecorder)recording=null;if(stream===jobStream)stream=null;chunks=[];if(!dead&&token===generation){busy=false;exportAbort=null;setControls();compose(prev);}}
 }
 async function exportVideo(){
  if(!prepared||busy)return;
  if(!root.NKPIReplayVideo?.supported())return exportVideoRealtime();
  stop();const token=++generation,abort=new AbortController(),prev=state.t;exportAbort=abort;busy=true;setControls();
  status('Building every movie frame locally at 30 fps. This avoids dropped frames from real-time screen recording.');
  try{const count=state.duration*30,blob=await root.NKPIReplayVideo.encode({canvas,count,fps:30,signal:abort.signal,drawFrame:(i,n)=>{if(dead||token!==generation)throw Error('Video export canceled.');const p=i/(n-1);compose(state.mode==='smooth'?F.phase(p):(p<.5?0:1),true);},onProgress:p=>status('Encoding smooth video · '+Math.round(p*100)+'% · 30 fps output')});
   if(dead||token!==generation)return;save(blob,'NKPI_continuous_transition_x'+(state.mode==='snapshots'?1:state.gain)+'.webm',true);status('30 fps movie saved and opened below. Every frame is included; only the two scan endpoints were observed.');
  }catch(e){if(!dead&&token===generation)status('Video not saved: '+e.message);}finally{if(!dead&&token===generation){busy=false;exportAbort=null;setControls();compose(prev);}}
 }
 on(q('[data-rp-prepare]'),'click',()=>prepare(true));on(q('[data-rp-play]'),'click',play);on(q('[data-rp-first]'),'click',()=>seek(0));on(q('[data-rp-last]'),'click',()=>seek(1));on(q('[data-rp-scrub]'),'input',e=>seek(+e.target.value/10000));
 for(const k of ['mode','field','view','gain'])on(q('[data-rp-'+k+']'),'change',e=>{state[k]=k==='gain'?+e.target.value:e.target.value;refresh();});
 on(q('[data-rp-duration]'),'change',e=>{state.duration=+e.target.value;lastTime=null;});for(const k of ['support','outline','loop'])on(q('[data-rp-'+k+']'),'change',e=>{state[k]=e.target.checked;refresh();});
 on(q('[data-rp-gif]'),'click',exportGIF);on(q('[data-rp-video]'),'click',exportVideo);on(q('[data-rp-png]'),'click',()=>{if(!busy&&prepared){compose(state.t,true);canvas.toBlob(b=>{if(b&&!dead)save(b,'NKPI_transition_x'+state.gain+'.png');if(!dead)compose(state.t);});}});on(q('[data-rp-cancel]'),'click',cancel);
 on(document,'visibilitychange',()=>{if(document.hidden){stop();if(busy&&exportAbort)cancel();}});
 setControls();compose(0);
 function dispose(){if(dead)return;stop();dead=true;generation++;exportAbort?.abort();terminateRecording();offs.forEach(f=>f());release();previewClear();for(const u of urls)URL.revokeObjectURL(u);urls.clear();for(const e of EYES)delete models[e];host.replaceChildren();if(host.__replay===dispose)delete host.__replay;}
 dispose.getState=()=>({...state});dispose.getInfo=()=>({prepared,busy,playing,mode:state.mode,t:state.t,position,gain:state.gain,drawCount,fractionChanges,fps,eyes:eligible,backend:Object.fromEntries(EYES.map(e=>[e,renderers[e]?.backend||null])),cachedImageFrames:0,vertices:Object.fromEntries(EYES.map(e=>[e,renderers[e]?.geometry.vertexCount||0])),compatibility:Object.fromEntries(EYES.map(e=>[e,models[e]?.compat||null]))});
 dispose.prepare=prepare;dispose.compose=t=>seek(t);dispose.capture=t=>{stop();compose(t,true);};dispose.play=play;dispose.exportGIF=exportGIF;dispose.exportVideo=exportVideo;dispose.cancel=cancel;host.__replay=dispose;return dispose;
}
root.NKPIReplay={mount,version:'9.2.1-fluid-replay'};
})(typeof window!=='undefined'?window:globalThis);
