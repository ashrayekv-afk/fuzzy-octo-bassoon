/* Continuous two-endpoint surface renderer. Display only; never edits source data.
 * Endpoint positions are sampled once. WebGL interpolates geometry on every draw;
 * the Canvas fallback does the same arithmetic, not a cached-image cross-fade.
 * Unshared source support is shown as fixed baseline/reference, never moving data. */
(function(root){'use strict';
const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const unit=a=>{const n=Math.hypot(...a)||1;return a.map(x=>x/n);};
const mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t);
function phase(p){return clamp((p-.08)/.84,0,1);}
function valid(p){return Array.isArray(p)&&p.length===3&&p.every(finite);}
function pose(a,b,t,gain=1,supported=true){return supported?mix(a,b,clamp(t,0,1)*gain):a.slice();}
function basis(view){const yaw=view==='front'?0:view==='profile'?-Math.PI/2:-1.0,pitch=view==='oblique'?.16:0;
 const c=Math.cos(yaw),s=Math.sin(yaw),a=Math.cos(pitch),b=Math.sin(pitch);
 return {right:[c,0,s],up:[b*s,a,-b*c],toward:[-a*s,b,a*c]};}
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
function point(model,x,y,back){const p=back?model.back(x,y):model.front(x,y);if(!valid(p))throw Error('A source surface contains invalid coordinates.');return p;}
function normal(model,x,y,back){if(!back)return unit(model.normal(x,y));const d=.015,a=model.back(x-d,y),b=model.back(x+d,y),c=model.back(x,y-d),e=model.back(x,y+d),u=b.map((v,i)=>v-a[i]),v=e.map((q,i)=>q-c[i]);return unit([-(u[1]*v[2]-u[2]*v[1]),-(u[2]*v[0]-u[0]*v[2]),-(u[0]*v[1]-u[1]*v[0])]);}
function buildGeometry(first,latest,{rings=32,sectors=112,compatible=true}={}){
 if(!first?.hasPatientGeometry||!latest?.hasPatientGeometry)throw Error('Two spatially supported reconstructions are required.');
 const radius=(compatible?Math.min(first.radius,latest.radius):first.radius)*.94,xy=[[0,0]],tri=[];
 for(let j=1;j<=rings;j++)for(let i=0;i<sectors;i++){const angle=i*2*Math.PI/sectors,r=radius*j/rings;xy.push([r*Math.cos(angle),r*Math.sin(angle)]);}
 for(let i=0;i<sectors;i++)tri.push([0,1+i,1+(i+1)%sectors]);
 for(let j=2;j<=rings;j++)for(let i=0;i<sectors;i++){const a=1+(j-2)*sectors+i,b=1+(j-2)*sectors+(i+1)%sectors,c=a+sectors,d=b+sectors;tri.push([a,c,d],[a,d,b]);}
 const p0=[],p1=[],n0=[],n1=[],support=[],side=[],coords=[],N=xy.length;
 for(const back of [false,true])for(const [x,y]of xy){
  const a=point(first,x,y,back),b=point(latest,x,y,back);
  const ok=compatible&&first.geometrySupported(x,y)&&latest.geometrySupported(x,y)&&(back?first.backSupported(x,y)&&latest.backSupported(x,y):true);
  p0.push(a);p1.push(b);n0.push(normal(first,x,y,back));n1.push(normal(latest,x,y,back));support.push(ok?1:0);side.push(back?1:0);coords.push([x,y]);
 }
 const indices=tri.flat();for(const t of tri)indices.push(t[2]+N,t[1]+N,t[0]+N);
 const edge=1+(rings-1)*sectors;for(let i=0;i<sectors;i++){const a=edge+i,b=edge+(i+1)%sectors;indices.push(a,b,a+N,b,b+N,a+N);}
 return {radius,xy:coords,p0,p1,n0,n1,support,side,indices:new Uint16Array(indices),vertexCount:p0.length,frontCount:N,compatible};
}
function projection(geometries,view,width,height,gain=1){
 const B=basis(view);let lo=[Infinity,Infinity],hi=[-Infinity,-Infinity];
 for(const G of geometries)if(G)for(let i=0;i<G.p0.length;i++)for(const p of [G.p0[i],pose(G.p0[i],G.p1[i],1,gain,G.support[i]===1)]){
  const q=[dot(p,B.right),dot(p,B.up)];for(let k=0;k<2;k++){lo[k]=Math.min(lo[k],q[k]);hi[k]=Math.max(hi[k],q[k]);}
 }
 if(!lo.every(finite))return {...B,center:[0,0],scale:20,width,height};
 // Equal physical axes; one shared camera/scale for both eyes and both visits.
 const scale=Math.min((width-48)/Math.max(.1,hi[0]-lo[0]),(height-32)/Math.max(.1,hi[1]-lo[1]));
 return {...B,center:lo.map((v,i)=>(v+hi[i])/2),scale,width,height};
}
function project(p,P){return [P.width/2+(dot(p,P.right)-P.center[0])*P.scale,P.height/2-(dot(p,P.up)-P.center[1])*P.scale,dot(p,P.toward)];}
const VS=`precision highp float;
attribute vec3 aP0,aP1,aN0,aN1;attribute float aV0,aV1;attribute vec3 aSupport;attribute float aSide;
uniform float uT,uGain;uniform vec3 uRight,uUp,uToward;uniform vec2 uCenter,uSize;uniform float uScale;
varying vec3 vNormal;varying vec3 vSupport;varying float vValue;varying float vSide;varying vec3 vObject;
void main(){float t=uT*uGain*aSupport.x;vec3 p=mix(aP0,aP1,t);vec3 n=normalize(mix(aN0,aN1,t));
 gl_Position=vec4(2.0*(dot(p,uRight)-uCenter.x)*uScale/uSize.x,2.0*(dot(p,uUp)-uCenter.y)*uScale/uSize.y,-dot(p,uToward)/32.0,1.0);
 vNormal=normalize(vec3(dot(n,uRight),dot(n,uUp),dot(n,uToward)));vSupport=aSupport;vValue=mix(aV0,aV1,uT);vSide=aSide;vObject=p;}`;
const FS=`precision highp float;
uniform float uMap,uShowSupport;uniform vec2 uRange;uniform vec3 uC0,uC1,uC2,uC3,uC4;
varying vec3 vNormal;varying vec3 vSupport;varying float vValue;varying float vSide;varying vec3 vObject;
vec3 palette(float t){float q=clamp(t,0.0,1.0)*4.0;if(q<1.0)return mix(uC0,uC1,q);if(q<2.0)return mix(uC1,uC2,q-1.0);if(q<3.0)return mix(uC2,uC3,q-2.0);return mix(uC3,uC4,q-3.0);}
void main(){vec3 n=normalize(vNormal);if(!gl_FrontFacing)n=-n;float diffuse=max(0.0,dot(n,normalize(vec3(-.5,.7,1.0))));
 float rim=pow(1.0-abs(n.z),2.6);float spec=pow(max(0.0,dot(n,normalize(vec3(-.25,.4,1.0)))),46.0);
 vec3 color=mix(vec3(.16,.39,.51),vec3(.42,.75,.84),diffuse);color+=rim*vec3(.18,.25,.28)+spec*vec3(.45,.5,.5);
 float alpha=mix(.84,.94,rim);if(vSide>.5){color*=.60;alpha=.92;}
 if(uMap>.5&&vSupport.y>.99&&vSupport.z>.99){color=palette((vValue-uRange.x)/max(.001,uRange.y-uRange.x));alpha=1.0;}
 else if(uMap>.5){color=vec3(.40,.43,.48);alpha=1.0;}
 if(vSupport.x<.99){color=mix(color,vec3(.41,.43,.47),.82);alpha=.73;}
 if(uShowSupport>.5){color=vSupport.x>.99?vec3(.18,.65,.71):vec3(.70,.51,.24);alpha=.95;}
 gl_FragColor=vec4(clamp(color,0.0,1.0),alpha);}`;
function create(canvas,geometry,first,latest,{forceCanvas=false,forceWebGL=false,onFailure=()=>{}}={}){
 let G=geometry;let gl=null,program=null,vbo=null,ibo=null,ctx=null,dead=false,lost=false,field='shape',bounds=null,locations={},mapValues=null;
 const stride=18,packed=new Float32Array(G.vertexCount*stride);
 for(let i=0;i<G.vertexCount;i++){const at=i*stride;packed.set(G.p0[i],at);packed.set(G.p1[i],at+3);packed.set(G.n0[i],at+6);packed.set(G.n1[i],at+9);packed[at+14]=G.support[i];packed[at+17]=G.side[i];}
 try{if(!forceCanvas)gl=canvas.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true,premultipliedAlpha:false});
  if(gl&&!forceWebGL){const ext=gl.getExtension('WEBGL_debug_renderer_info'),name=ext?String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)):'';if(/SwiftShader|llvmpipe|software raster/i.test(name)){gl.getExtension('WEBGL_lose_context')?.loseContext();gl=null;}}
  if(gl){const shader=(type,code)=>{const s=gl.createShader(type);gl.shaderSource(s,code);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){const e=gl.getShaderInfoLog(s);gl.deleteShader(s);throw Error(e);}return s;};
   const vs=shader(gl.VERTEX_SHADER,VS),fs=shader(gl.FRAGMENT_SHADER,FS);program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
   gl.useProgram(program);vbo=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferData(gl.ARRAY_BUFFER,packed,gl.DYNAMIC_DRAW);ibo=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibo);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,G.indices,gl.STATIC_DRAW);
   for(const [name,n,offset]of [['aP0',3,0],['aP1',3,3],['aN0',3,6],['aN1',3,9],['aV0',1,12],['aV1',1,13],['aSupport',3,14],['aSide',1,17]]){const loc=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,n,gl.FLOAT,false,stride*4,offset*4);}
   for(const k of ['T','Gain','Right','Up','Toward','Center','Size','Scale','Map','ShowSupport','Range','C0','C1','C2','C3','C4'])locations[k]=gl.getUniformLocation(program,'u'+k);
  }
 }catch(e){if(gl){try{gl.deleteBuffer(vbo);gl.deleteBuffer(ibo);gl.deleteProgram(program);}catch(_){}}gl=null;onFailure('GPU renderer unavailable: '+String(e.message||e));}
 // A canvas cannot switch context types after WebGL allocation. Use a separate
 // software canvas for fallback and expose it through .canvas.
 let active=canvas;if(!gl){if(G.vertexCount>1800)G=buildGeometry(first,latest,{rings:13,sectors:64});active=document.createElement('canvas');active.width=canvas.width;active.height=canvas.height;ctx=active.getContext('2d');}
 function contextLost(e){e.preventDefault();lost=true;onFailure('Graphics context lost. Rebuild replay to restart; extraction is unaffected.');}
 if(gl)canvas.addEventListener('webglcontextlost',contextLost);
 function setField(next,scale){field=next;bounds=scale;mapValues={a:new Float32Array(G.vertexCount),b:new Float32Array(G.vertexCount),s0:new Uint8Array(G.vertexCount),s1:new Uint8Array(G.vertexCount)};
  for(let i=0;i<G.vertexCount;i++){const [x,y]=G.xy[i],a=first.reading?.(field,x,y),b=latest.reading?.(field,x,y);const good=r=>r?.kind==='source'&&finite(r.value);
   const sa=good(a),sb=good(b);mapValues.a[i]=sa?a.value:0;mapValues.b[i]=sb?b.value:0;mapValues.s0[i]=sa?1:0;mapValues.s1[i]=sb?1:0;
   packed[i*stride+12]=mapValues.a[i];packed[i*stride+13]=mapValues.b[i];packed[i*stride+15]=sa?1:0;packed[i*stride+16]=sb?1:0;
  }
  if(gl&&!lost){gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferSubData(gl.ARRAY_BUFFER,0,packed);}
 }
 setField('shape',null);
 function draw(t,{gain=1,support=false,projection:P}={}){
  if(dead||lost)return false;if(!P)throw Error('Replay projection is required.');
  if(gl){gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.disable(gl.CULL_FACE);
   const u=locations;gl.uniform1f(u.T,clamp(t,0,1));gl.uniform1f(u.Gain,gain);gl.uniform3fv(u.Right,P.right);gl.uniform3fv(u.Up,P.up);gl.uniform3fv(u.Toward,P.toward);gl.uniform2fv(u.Center,P.center);gl.uniform2f(u.Size,P.width,P.height);gl.uniform1f(u.Scale,P.scale);
   gl.uniform1f(u.Map,field!=='shape'&&bounds?1:0);gl.uniform1f(u.ShowSupport,support?1:0);gl.uniform2f(u.Range,bounds?.min||0,bounds?.max||1);
   const colors=bounds?.stops||[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]];colors.forEach((c,i)=>gl.uniform3fv(u['C'+i],c));
   gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibo);gl.drawElements(gl.TRIANGLES,G.indices.length,gl.UNSIGNED_SHORT,0);return true;
  }
  // Lower-resolution Canvas fallback keeps genuine per-frame geometry updates.
  const points=G.p0.map((p,i)=>project(pose(p,G.p1[i],t,gain,G.support[i]===1),P)),tri=[];
  for(let j=0;j<G.indices.length;j+=3){const ids=[G.indices[j],G.indices[j+1],G.indices[j+2]];tri.push({ids,z:ids.reduce((v,i)=>v+points[i][2],0)/3});}
  tri.sort((a,b)=>a.z-b.z);ctx.clearRect(0,0,active.width,active.height);
  for(const {ids}of tri){const n=unit(ids.reduce((out,i)=>out.map((v,k)=>v+G.n0[i][k]+(G.n1[i][k]-G.n0[i][k])*t*gain*G.support[i]),[0,0,0]));
   const diffuse=Math.abs(dot(n,unit([-.4,.6,1]))),known=ids.every(i=>G.support[i]===1);let color=[.16+.32*diffuse,.39+.34*diffuse,.51+.30*diffuse];
   if(field!=='shape'&&bounds){const ok=ids.every(i=>mapValues.s0[i]&&mapValues.s1[i]),value=ids.reduce((s,i)=>s+mapValues.a[i]+(mapValues.b[i]-mapValues.a[i])*t,0)/3;color=ok?(root.NKPIIntegratedMeasurements?.colorAt(field,value,bounds)||[.4,.43,.48]):[.4,.43,.48];}
   if(!known)color=color.map((v,i)=>v*.18+[.41,.43,.47][i]*.82);if(support)color=known?[.18,.65,.71]:[.70,.51,.24];
   ctx.fillStyle='rgb('+color.map(v=>Math.round(clamp(v,0,1)*255)).join(',')+')';ctx.beginPath();ids.forEach((i,k)=>k?ctx.lineTo(points[i][0],points[i][1]):ctx.moveTo(points[i][0],points[i][1]));ctx.closePath();ctx.fill();
  }return true;
 }
 return {canvas:active,backend:gl?'WebGL continuous geometry':'Canvas continuous geometry',setField,draw,geometry:G,dispose(){if(dead)return;dead=true;if(gl){canvas.removeEventListener('webglcontextlost',contextLost);if(!lost){gl.deleteBuffer(vbo);gl.deleteBuffer(ibo);gl.deleteProgram(program);}gl.getExtension('WEBGL_lose_context')?.loseContext();}active.width=1;active.height=1;}};
}
const api={phase,pose,basis,projection,project,buildGeometry,create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIFluidRenderer=api;
})(typeof window!=='undefined'?window:globalThis);
