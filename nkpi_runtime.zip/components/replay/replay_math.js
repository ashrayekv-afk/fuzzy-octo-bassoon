/* Two-visit observations and DISPLAY-ONLY interpolation. No model inputs are edited. */
(function(root){'use strict';
const finite=Number.isFinite, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const FIELDS=[
 {id:'A',label:'A / ARC',unit:'mm',decimals:2,decrease:'steepening',increase:'flattening'},
 {id:'B',label:'B / PRC',unit:'mm',decimals:2,decrease:'steepening',increase:'flattening'},
 {id:'C',label:'C / thinnest pachymetry',unit:'µm',decimals:0,decrease:'thinning',increase:'thickening'},
 {id:'Kmax',label:'Kmax',unit:'D',decimals:2,decrease:'decrease',increase:'increase'},
 {id:'BAD_D',label:'BAD-D',unit:'',decimals:2,decrease:'decrease',increase:'increase'},
 {id:'ARTmax',label:'ARTmax',unit:'',decimals:1,decrease:'decrease',increase:'increase'}
];
function observations(result,eye){
 const c=result?.case;
 if(!c||c.eye!==eye||c.verified!==true||c.mode!=='longitudinal'||!finite(c.interval_days)||c.interval_days<=0)return null;
 const rows=FIELDS.map(f=>{
  const a=c.first?.[f.id],b=c.latest?.[f.id],ok=finite(a)&&finite(b),delta=ok?b-a:null;
  return {...f,first:finite(a)?a:null,latest:finite(b)?b:null,delta,rate:ok?delta*365.25/c.interval_days:null,
   direction:!ok?'unavailable':delta===0?'unchanged':delta<0?f.decrease:f.increase};
 });
 return {eye,days:c.interval_days,rows,shortInterval:c.interval_days<90,
  treatment:c.history?.cxl||c.history?.prior_cxl||null};
}
function reportPair(sets,eye){
 const reports=(Array.isArray(sets)?sets:[]).filter(s=>s?.eye===eye),a=reports.filter(s=>s.visit==='first'),b=reports.filter(s=>s.visit==='latest');
 if(a.length!==1||b.length!==1)return null;
 return {first:a[0],latest:b[0]};
}
function geometryCompatibility(a,b){
 if(!a?.source||!b?.source||!a.hasPatientGeometry||!b.hasPatientGeometry)return {ok:false,reason:'Patient-supported geometry is required at both visits. Scalar measurements alone cannot supply a moving cornea.'};
 if(a.report?.eye!==b.report?.eye||a.report?.visit!=='first'||b.report?.visit!=='latest')return {ok:false,reason:'The surface eye/visit association is not valid.'};
 if(a.source.kind!==b.source.kind)return {ok:false,reason:'Source reconstruction types differ. Use observed snapshots only.'};
 const sameAxis=(x,y)=>x?.length===y?.length&&x?.length>1&&x.every((v,i)=>finite(v)&&finite(y[i])&&Math.abs(v-y[i])<1e-6);
 if(!sameAxis(a.source.axisX,b.source.axisX)||!sameAxis(a.source.axisY,b.source.axisY)||Math.abs(a.limbus-b.limbus)>1e-6||Math.abs(a.radius-b.radius)>1e-6)return {ok:false,reason:'Spatial grids or source fields differ. Use observed snapshots; no automatic registration or resampling is applied.'};
 let supported=0,total=0;
 for(let y=-a.radius;y<=a.radius;y+=a.radius/10)for(let x=-a.radius;x<=a.radius;x+=a.radius/10)if(Math.hypot(x,y)<=a.radius){total++;if(a.geometrySupported(x,y)&&b.geometrySupported(x,y))supported++;}
 if(!supported)return {ok:false,reason:'There is no shared source-supported geometry.'};
 return {ok:true,coverage:supported/total,reason:a.source.kind==='native'?'Display-coordinate interpolation; anatomical registration is not verified.':'Image-derived display interpolation, not a measured deformation. Reference surfaces can differ.'};
}
function interpolate(a,b,t){
 if(!finite(t)||t<0||t>1)throw Error('Replay fraction must be between zero and one.');
 if(t===0)return a;if(t===1)return b;
 const check=geometryCompatibility(a,b);if(!check.ok)throw Error(check.reason);
 const blend=(p,q)=>p.map((v,i)=>v+(q[i]-v)*t),front=(x,y)=>blend(a.front(x,y),b.front(x,y));
 const normal=(x,y)=>{const d=.025,fx=front(x+d,y)[2]-front(x-d,y)[2],fy=front(x,y+d)[2]-front(x,y-d)[2],v=[-fx/(2*d),-fy/(2*d),1],n=Math.hypot(...v);return v.map(q=>q/n);};
 const maps={};for(const field of Object.keys(a.maps||{})){const am=a.maps[field],bm=b.maps?.[field];if(!bm||am.direct.status.length!==bm.direct.status.length)continue;maps[field]={...am,direct:{...am.direct,status:Uint8Array.from(am.direct.status,(v,i)=>v===1&&bm.direct.status[i]===1?1:0)}};}
 return {source:a.source,report:null,result:null,radius:a.radius,limbus:a.limbus,front,normal,maps,
  back:(x,y)=>blend(a.back(x,y),b.back(x,y)),
  geometrySupported:(x,y)=>a.geometrySupported(x,y)&&b.geometrySupported(x,y),
  backSupported:(x,y)=>a.backSupported(x,y)&&b.backSupported(x,y),
  visual:(f,x,y)=>{const p=a.visual(f,x,y),q=b.visual(f,x,y);return finite(p)&&finite(q)?p+(q-p)*t:null;},
  reading:()=>({value:null,kind:'unavailable',origin:'Illustrative intermediate frame; not a measured visit'}),
  verifiedC:null,minimum:null,hasPatientGeometry:true,interpolated:true,fraction:t};
}
function phase(position,mode){
 const p=clamp(position,0,1);
 // Endpoint dwell for legibility; interpolation is linear during the middle 60%.
 const t=clamp((p-.20)/.60,0,1);
 return mode==='smooth'?t:(p<.5?0:1);
}
function status(t){return t===0?'BASELINE · observed scan reconstruction':t===1?'LATEST · observed scan reconstruction':'ILLUSTRATIVE TRANSITION · not a measured scan';}
const api={FIELDS,observations,reportPair,geometryCompatibility,interpolate,phase,status};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIReplayMath=api;
})(typeof window!=='undefined'?window:globalThis);
