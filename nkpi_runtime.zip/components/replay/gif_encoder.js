/* Local GIF89a encoder: adaptive global palette + LZW. No network or dependencies. */
(function(root){'use strict';
function paletteFor(frames){
 const hist=new Uint32Array(32768),sumR=new Float64Array(32768),sumG=new Float64Array(32768),sumB=new Float64Array(32768);
 for(const f of frames){const d=f.data;for(let i=0;i<d.length;i+=16){const r=d[i],g=d[i+1],b=d[i+2],k=(r>>3)*1024+(g>>3)*32+(b>>3);hist[k]++;sumR[k]+=r;sumG[k]+=g;sumB[k]+=b;}}
 const colors=[];for(let k=0;k<32768;k++)if(hist[k])colors.push([sumR[k]/hist[k],sumG[k]/hist[k],sumB[k]/hist[k],hist[k]]);
 if(!colors.length)return Array.from({length:256},()=>[0,0,0]);
 function bucket(c){let weight=0,lo=[255,255,255],hi=[0,0,0];for(const q of c){weight+=q[3];for(let j=0;j<3;j++){lo[j]=Math.min(lo[j],q[j]);hi[j]=Math.max(hi[j],q[j]);}}const spans=hi.map((v,i)=>v-lo[i]);return {c,weight,spans,score:Math.max(...spans)*Math.sqrt(weight)};}
 const boxes=[bucket(colors)];while(boxes.length<256){let ix=-1,best=-1;boxes.forEach((b,i)=>{if(b.c.length>1&&b.score>best){best=b.score;ix=i;}});if(ix<0)break;const b=boxes[ix],axis=b.spans.indexOf(Math.max(...b.spans));b.c.sort((a,c)=>a[axis]-c[axis]);let w=0,cut=1;for(let i=0;i<b.c.length-1;i++){w+=b.c[i][3];cut=i+1;if(w>=b.weight/2)break;}boxes.splice(ix,1,bucket(b.c.slice(0,cut)),bucket(b.c.slice(cut)));}
 const palette=boxes.map(b=>[0,1,2].map(i=>Math.round(b.c.reduce((s,c)=>s+c[i]*c[3],0)/b.weight)));
 while(palette.length<256)palette.push([0,0,0]);return palette;
}
function indexPixels(data,palette,lookup){
 const out=new Uint8Array(data.length/4);for(let i=0,j=0;i<data.length;i+=4,j++){const r=data[i],g=data[i+1],b=data[i+2],key=(r>>3)*1024+(g>>3)*32+(b>>3);let q=lookup[key];if(q<0){let best=Infinity;q=0;for(let k=0;k<256;k++){const c=palette[k],dist=(r-c[0])**2+(g-c[1])**2+(b-c[2])**2;if(dist<best){best=dist;q=k;}}lookup[key]=q;}out[j]=q;}return out;
}
function lzw(pixels){
 const bytes=[];let bits=0,nBits=0,width=9,next=258,dict=new Map();
 const emit=code=>{bits|=code<<nBits;nBits+=width;while(nBits>=8){bytes.push(bits&255);bits>>>=8;nBits-=8;}};
 emit(256);let prefix=pixels[0];
 for(let i=1;i<pixels.length;i++){const v=pixels[i],key=prefix*256+v,known=dict.get(key);if(known!==undefined){prefix=known;continue;}emit(prefix);
  if(next<4096){dict.set(key,next++);if(next>(1<<width)&&width<12)width++;}else{emit(256);dict=new Map();width=9;next=258;}
  prefix=v;
 }
 emit(prefix);emit(257);if(nBits)bytes.push(bits&255);return Uint8Array.from(bytes);
}
async function encodeStream({count,frameAt,paletteFrames,width,height,delays,signal,onProgress=()=>{}}={}){
 if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>1600||height>1200||!Number.isInteger(count)||count<1||count>600||typeof frameAt!=='function')throw Error('Invalid or oversized GIF frames.');
 const check=()=>{if(signal?.aborted)throw Error('GIF export canceled.');};check();
 const samples=paletteFrames||[await frameAt(0)];
 if(samples.some(f=>f.data?.length!==width*height*4))throw Error('GIF frame dimensions do not match.');
 const palette=paletteFor(samples),lookup=new Int16Array(32768).fill(-1),parts=[];
 const push=a=>parts.push(Uint8Array.from(a)),word=v=>[v&255,(v>>8)&255];
 push([...new TextEncoder().encode('GIF89a'),...word(width),...word(height),0xf7,0,0]);push(palette.flat());
 push([0x21,0xff,11,...new TextEncoder().encode('NETSCAPE2.0'),3,1,0,0,0]);
 for(let i=0;i<count;i++){
  check();const frame=await frameAt(i);check();if(frame.data?.length!==width*height*4)throw Error('GIF frame dimensions do not match.');
  const delay=Math.max(2,Math.min(65535,Math.round(typeof delays==='function'?delays(i):delays?.[i]??10)));
  push([0x21,0xf9,4,4,...word(delay),0,0]);push([0x2c,0,0,0,0,...word(width),...word(height),0,8]);
  const data=lzw(indexPixels(frame.data,palette,lookup));for(let k=0;k<data.length;k+=255){const chunk=data.subarray(k,k+255);push([chunk.length]);parts.push(chunk);}push([0]);
  onProgress((i+1)/count);await new Promise(r=>setTimeout(r,0));
 }check();push([0x3b]);return new Blob(parts,{type:'image/gif'});
}
async function encode(frames,options={}){
 if(!frames?.length||frames.length>90)throw Error('Invalid or oversized GIF frames.');
 return encodeStream({...options,count:frames.length,frameAt:i=>frames[i],paletteFrames:frames});
}
const api={encode,encodeStream,paletteFor,indexPixels,lzw};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIReplayGIF=api;
})(typeof window!=='undefined'?window:globalThis);
