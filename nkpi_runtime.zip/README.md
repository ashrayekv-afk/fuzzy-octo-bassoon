# NKPI 9.2.0 — October 27 reader + corneal progression replay

## Install this four-file package
Extract the OUTER NKPI_Oct27_Extractor_Replay_GitHub.zip once. Upload these files
together to the ROOT of the GitHub repository connected to your existing app,
replacing matching files:

    kcn_dual_calculator_app.py
    nkpi_runtime.zip
    requirements.txt
    README.md

Keep nkpi_runtime.zip zipped. The Python launcher and runtime ZIP are a matched
SHA-256 pair. Do not mix them with earlier packages. No hidden folder or extra
repository is required. Existing optional .streamlit/config.toml settings may stay.
Keep kcn_dual_calculator_app.py as the Streamlit main file and Python 3.12 as the
deployment target. Reboot the existing app after uploading all four files, then
refresh its page. Check for Build 9.2.0 and October 27 extraction rules.

## Which extraction method this uses
The extraction source is NKPI_v910_GitHub_Upload.zip, archived October 27, 2026.
The original 34 extractor source/vendor/model files are included unchanged.
This is not the failed v9.1.5.3 parallel/alignment upgrade. The crop positions,
numeric parsing, eye/visit association, cross-checks, recognition models, and
human source-verification requirements come from the archived extractor.

Delivery was repaired separately. The main component carries the complete importer
as a srcdoc document. OCR libraries, workers, the original automatically selected
primary core, the original portable secondary core, and both English models are
embedded from their original bytes. OCR needs no separate HTTP asset requests after
the component document arrives. Compiled relative URL references use the explicit
same-origin base URI. Browser security checks are not disabled; CORS/XSRF settings
are not changed. Optional PDF/TIFF decoders keep their existing loader requirements.

There is no claim that OCR needs no setup: the browser must still instantiate the
engines. The misleading 'first visit' cache wording is removed. Worker setup means
browser preparation, not the patient's first examination. A failed setup now stops
automatic extraction; it cannot be labeled a completed extraction with 0 values.
The original optional manual page selector is inside technical help and is never
automatically selected as the primary workflow.

## New features retained
The purple bilateral interface, natural-eye corneal viewer, thinnest-point logic,
ranked model audit, baseline/latest replay, and local GIF / video / still export
are retained. Replay is prepared only when selected; it adds no OCR work. In a
longitudinal case, verify the values and calculate, then scroll below the 3D view
and choose Prepare replay. Both visits need supported spatial data. Scalar values
alone cannot create a patient-specific progressing cornea.

Observed mode switches between actual reconstructed visit endpoints. Smooth mode
is labeled display interpolation, not a measured intermediate scan, prediction,
proof of progression, or exact anatomical reconstruction. Missing spatial data
remain unavailable. Video export uses the browser-supported format (WebM in the
Chromium checks); this is not an MP4-only exporter. GIF is separate.

## Verification
See docs/RELEASE_VERIFICATION.md and docs/SOURCE_PROVENANCE.json inside the runtime.
Checks use synthetic engineering data, not your patient ZIPs. The original
Oct 27 model artifacts and clinical calculations are unchanged.
The live Community Cloud deployment and managed clinic browser/network have NOT
been verified. Do not equate software checks with clinical accuracy validation.

## Local reproduction
    python -m pip install -r requirements.txt
    python -m streamlit run kcn_dual_calculator_app.py

The launcher verifies the archive and builds the self-contained documents before
publishing the extracted runtime. Developers working directly in the internal
runtime should run python tools/build_delivery.py before tests. Do not run old
builders copied from another release.

## Privacy
Original report images and ZIPs stay in browser memory. Only confirmed deidentified
numeric inputs are sent for calculation, as in the previous calculator. No patient
exports, identifiers, clinical screenshots, API keys or credentials are included.
Use only institutionally approved hosting for patient data. Browser-only OCR does
not itself establish privacy/compliance approval. Keep patient ZIPs out of GitHub.
