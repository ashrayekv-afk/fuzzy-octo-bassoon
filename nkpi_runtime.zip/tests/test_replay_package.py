from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
def test_restored_extractor_cornea_and_models_are_unchanged():
    for file,sha in json.loads((R/'docs/REPLAY_PRESERVED_HASHES.json').read_text()).items():
        assert hashlib.sha256((R/file).read_bytes()).hexdigest()==sha,file

def test_no_extraction_upgrade_pipeline_is_carried_forward():
    for name in ['extraction_flow.js','extraction_pipeline.js','measurement_alignment.js','label_binding.js']:
        assert not (R/'components/extractor'/name).exists()

def test_replay_included_before_binding_controller():
    text=(R/'components/index.template.html').read_text()
    assert text.index('replay/replay_view.js')<text.index('regional_change.js')
    assert 'replay/replay.css' in text

def test_replay_has_no_network_or_record_upload_calls():
    for name in ['replay_math.js','replay_view.js','gif_encoder.js','fluid_renderer.js','webm_encoder.js']:
        text=(R/'components/replay'/name).read_text()
        assert 'fetch(' not in text
        assert 'XMLHttpRequest' not in text
        assert 'localStorage' not in text

def test_replay_is_gated_by_existing_source_bindings():
    text=(R/'components/regional_change.js').read_text()
    assert "const bilateralSets={OD:boundShapeSets('OD'),OS:boundShapeSets('OS')}" in text
    assert "NKPIReplay.mount(el.querySelector('#rg-progression-replay'),bilateralSets" in text
