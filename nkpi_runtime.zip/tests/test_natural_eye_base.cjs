'use strict';
const assert=require('node:assert/strict');
const N=require('../components/cornea/natural_eye_base.js');
const R=require('../components/cornea/continuous_review.js');
const I=require('../components/cornea/integrated_model.js');
const fs=require('node:fs');
let count=0;const check=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const rot=(p,yaw,pitch)=>{const cy=Math.cos(yaw),sy=Math.sin(yaw),ca=Math.cos(pitch),sa=Math.sin(pitch);const x=cy*p[0]+sy*p[2],z=-sy*p[0]+cy*p[2];return [x,ca*p[1]-sa*z,sa*p[1]+ca*z];};
check('New renderer and existing orthographic cameras agree for every tested angle',()=>{
 for(const y of [-1.48,-.86,0,.6,1.48])for(const p of [-.6,0,.3])for(const v of [[1,2,3],[-4,0,-2],[0,0,0]]){
 const r=N.rotation(y,p),actual=[0,1,2].map(i=>v.reduce((s,x,j)=>s+x*r[j*3+i],0));const target=rot(v,y,p);actual.forEach((x,i)=>assert(Math.abs(x-target[i])<2e-6));}
});
const model={limbus:5.75,front:(x,y)=>[x,y,Math.sqrt(7.8**2-x*x-y*y)-7.8]};
const ref=N.referenceGeometry(model);
check('Reference scleral opening meets the corneal limbus without altering a surface point',()=>{
 const expected=ref.centerZ+Math.sqrt(ref.radius**2-ref.limbus**2);assert(Math.abs(expected-ref.limbusZ)<1e-12);assert(ref.irisZ<ref.limbusZ);assert(ref.irisRadius<ref.limbus);
});
check('Reference globe has finite normals and no triangle crosses the anterior opening',()=>{
 const s=N.sphereMesh(ref);assert(s.positions.every(p=>p.every(Number.isFinite)));assert(s.normals.every(n=>Math.abs(Math.hypot(...n)-1)<1e-10));assert(s.positions.every(p=>p[2]<=ref.limbusZ+1e-9));assert(s.triangles.every(t=>t.length===3&&t.every(i=>i>=0&&i<s.positions.length)));
});
check('Iris remains reference geometry behind the limbus; no patient iris appearance is inferred',()=>{const i=N.irisMesh(ref);assert(i.positions.every(p=>p[2]===ref.irisZ));assert(i.positions.every(p=>Math.hypot(p[0],p[1])<=ref.irisRadius+1e-9));});
check('Rendering module performs no reconstruction, risk calculation, or source-array writes',()=>{
 const js=fs.readFileSync(require.resolve('../components/cornea/natural_eye_base.js'),'utf8');
 assert(!js.includes('calculate('));assert(!js.includes('findThinnest('));assert(!js.includes('model.front ='));assert(!js.includes('model.back ='));assert(js.includes('this.geometry(mesh.points,mesh.normals,mesh.triangles'));
});
check('Map pass stays opaque and unlit while anatomy has its own transparent pass',()=>{const js=fs.readFileSync(require.resolve('../components/cornea/natural_eye_base.js'),'utf8');assert(js.includes('vec4(map.rgb,1.)'));assert(js.includes('gl.depthMask(false)'));assert(js.includes('this.draw(this.scene.front,3)'));});
check('Renderer has explicit context-loss fallback and resource cleanup',()=>{const js=fs.readFileSync(require.resolve('../components/cornea/natural_eye_base.js'),'utf8');for(const key of ['webglcontextlost','webglcontextrestored','deleteBuffer','deleteTexture','deleteProgram','forceFallback'])assert(js.includes(key));});
check('No runtime CDN or remote image assets added by the appearance update',()=>{const js=fs.readFileSync(require.resolve('../components/cornea/natural_eye_base.js'),'utf8');for(const key of ['fetch(','https://','http://','new Image('])assert(!js.includes(key));});
console.log(count+' natural appearance checks passed');
