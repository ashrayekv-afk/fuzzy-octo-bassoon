'use strict';
const assert=require('node:assert/strict'),fs=require('fs');
const X=require('../components/replay/replay_math.js'),I=require('../components/cornea/integrated_model.js'),R=require('../components/cornea/continuous_review.js');
let count=0;function test(name,fn){fn();count++;console.log('PASS '+name);}
function fixture(eye='OD',visit='first'){
 const n=31,a=Array.from({length:n},(_,i)=>-4.5+i*.3),g=fn=>a.map(y=>a.map(x=>Math.hypot(x,y)>4.5?null:fn(x,y))),later=visit==='latest',bump=(x,y)=>Math.exp(-((x-.3)**2+(y+.8)**2)/1.3),z=(x,y)=>Math.sqrt(7.8**2-x*x-y*y)-7.8+(.07+(later?.10:0))*bump(x,y),th=(x,y)=>470+(eye==='OS'?15:0)+7*(x*x+(y+.7)**2)-(later?15:0)*bump(x,y);
 return {eye,visit,source_id:eye+'-'+visit,pages:[],surface:{schema:'nkpi-corneal-surface-1',kind:'measured',source:'device_numeric_export',eye,visit,units:{xy:'mm',z:'mm',elevation:'um',thickness:'um',curvature:'D'},coordinate_system:{origin:'corneal_vertex',x_positive:eye==='OD'?'nasal':'temporal',y_positive:'superior',z_positive:'anterior'},x_mm:a,y_mm:a,anterior:{z_mm:g(z),curvature_D:g((x,y)=>44+(8+(later?2:0))*bump(x,y)),curvature_type:'axial',elevation_um:g((x,y)=>(70+(later?100:0))*bump(x,y)),elevation_reference:{type:'best_fit_sphere',fit_diameter_mm:8}},posterior:{z_mm:g((x,y)=>z(x,y)-th(x,y)/1000),curvature_D:g((x,y)=>-7.8-(later?.2:0)*bump(x,y)),curvature_type:'axial'},thickness_um:g(th),thickness_definition:'device_pachymetry'}};
}
function result(eye){return {case:{eye,mode:'longitudinal',verified:true,interval_days:180,first:{A:7.20,B:5.80,C:470+(eye==='OS'?15:0),Kmax:52,BAD_D:6,ARTmax:200},latest:{A:7.10,B:5.70,C:455+(eye==='OS'?15:0),Kmax:54,BAD_D:6.8,ARTmax:185}}};}
const pair={first:fixture(),latest:fixture('OD','latest')},a=R.build(I.fromReport(pair.first),pair.first,result('OD')),b=R.build(I.fromReport(pair.latest),pair.latest,result('OD')),before=JSON.stringify([pair,a.source,b.source]);
test('Exact observed delta and elapsed-year rates',()=>{const o=X.observations(result('OD'),'OD');assert.equal(o.days,180);const c=o.rows.find(x=>x.id==='C');assert.equal(c.delta,-15);assert.equal(c.rate,-15*365.25/180);assert.equal(c.direction,'thinning');assert.equal(o.rows.find(x=>x.id==='B').direction,'steepening');});
test('No rate for one visit, unverified input, wrong eye or zero interval',()=>{for(const patch of [{mode:'baseline'},{verified:false},{eye:'OS'},{interval_days:0}])assert.equal(X.observations({case:{...result('OD').case,...patch}},'OD'),null);});
test('No missing value replaced by zero',()=>{const r=result('OD');r.case.latest.C=null;assert.equal(X.observations(r,'OD').rows.find(x=>x.id==='C').rate,null);});
test('No source pair inferred from scalars or duplicate visits',()=>{assert.equal(X.reportPair([],'OD'),null);assert.equal(X.reportPair([pair.first,pair.first,pair.latest],'OD'),null);assert.equal(X.reportPair([pair.first,pair.latest],'OS'),null);});
test('Matched grids permit explicitly illustrative interpolation',()=>assert(X.geometryCompatibility(a,b).ok));
test('Endpoints are exact original models',()=>{assert.equal(X.interpolate(a,b,0),a);assert.equal(X.interpolate(a,b,1),b);});
test('Interior frame has no verified values, minimum, result or measurements',()=>{const m=X.interpolate(a,b,.5);assert.equal(m.verifiedC,null);assert.equal(m.minimum,null);assert.equal(m.result,null);assert.equal(m.reading('thickness',0,0).value,null);assert(m.interpolated);});
test('Interpolation changes display coordinates only',()=>{const m=X.interpolate(a,b,.5);assert(Math.abs(m.front(.3,-.8)[2]-(a.front(.3,-.8)[2]+b.front(.3,-.8)[2])/2)<1e-12);assert.equal(JSON.stringify([pair,a.source,b.source]),before);});
test('Missing geometry disables smooth animation',()=>{assert(!X.geometryCompatibility({...a,hasPatientGeometry:false},b).ok);});
test('Changed eye or grid cannot be morphed',()=>{assert(!X.geometryCompatibility(a,{...b,report:{...b.report,eye:'OS'}}).ok);assert(!X.geometryCompatibility(a,{...b,source:{...b.source,axisX:[1,2]}}).ok);});
test('Invalid fractions reject rather than extrapolate',()=>{assert.throws(()=>X.interpolate(a,b,1.2));assert.throws(()=>X.interpolate(a,b,NaN));});
test('Endpoint playback contains no intermediate geometry',()=>{for(let i=0;i<100;i++)assert([0,1].includes(X.phase(i/100,'snapshots')));});
test('Smooth mode holds endpoints and uses explicitly labeled middle',()=>{assert.equal(X.phase(.1,'smooth'),0);assert.equal(X.phase(.9,'smooth'),1);assert(Math.abs(X.phase(.5,'smooth')-.5)<1e-12);assert(X.status(.5).includes('not a measured scan'));});
console.log(count+' replay tests passed');
if(process.env.WRITE_REPLAY_FIXTURE)fs.writeFileSync(process.env.WRITE_REPLAY_FIXTURE,JSON.stringify({synthetic:true,sets:{OD:[fixture('OD','first'),fixture('OD','latest')],OS:[fixture('OS','first'),fixture('OS','latest')]},results:{OD:result('OD'),OS:result('OS')}}));
