'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),V=require('../components/replay/webm_encoder.js');
(async()=>{
 const webp=fs.readFileSync(path.join(__dirname,'fixtures/fluid_test_frame.webp'));
 const vp8=V.parseVP8(webp,8,8);assert(vp8.length>10);assert.throws(()=>V.parseVP8(webp,9,8),/dimensions/);assert.throws(()=>V.parseVP8(new Uint8Array(16),8,8),/WebP/);
 assert.deepEqual([...V.bytes(0x1a45dfa3)],[0x1a,0x45,0xdf,0xa3]);assert.deepEqual([...V.size(126)],[254]);assert.equal(V.size(127).length,2);
 let calls=0;const canvas={width:8,height:8,toBlob:fn=>fn(new Blob([webp],{type:'image/webp'}))};
 const blob=await V.encode({canvas,count:60,fps:30,drawFrame:(i,n)=>{assert.equal(i,calls++);assert.equal(n,60);}});assert.equal(calls,60);assert.equal(blob.type,'video/webm');const b=new Uint8Array(await blob.arrayBuffer());assert.deepEqual([...b.slice(0,4)],[0x1a,0x45,0xdf,0xa3]);
 const a=new AbortController();a.abort();await assert.rejects(V.encode({canvas,count:2,drawFrame(){},signal:a.signal}),/canceled/);
 await assert.rejects(V.encode({canvas,count:0,drawFrame(){}}),/Invalid/);
 const bad={width:8,height:8,toBlob:fn=>fn(new Blob([new Uint8Array(20)],{type:'image/png'}))};await assert.rejects(V.encode({canvas:bad,count:2,drawFrame(){}}),/WebP/);
 if(process.env.VIDEO_TEST_OUT)fs.writeFileSync(process.env.VIDEO_TEST_OUT,b);
 console.log('PASS deterministic video: real VP8 keyframe parsing, dimension checks, EBML sizing, 60 encoded frames, cancellation, invalid requests and PNG fallback rejection.');
})().catch(e=>{console.error(e);process.exitCode=1;});
