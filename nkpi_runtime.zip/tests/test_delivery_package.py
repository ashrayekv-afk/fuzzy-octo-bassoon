"""Delivery/package checks. These do not measure real-report accuracy."""
from pathlib import Path
from html.parser import HTMLParser
import base64,gzip,hashlib,json,re
R=Path(__file__).resolve().parents[1]
class Scripts(HTMLParser):
 def __init__(self,text):
  super().__init__();self.items=[];self.current=None;self.feed(text)
 def handle_starttag(self,tag,attrs):
  if tag=='script':self.current=[dict(attrs),'']
 def handle_data(self,data):
  if self.current is not None:self.current[1]+=data
 def handle_endtag(self,tag):
  if tag=='script' and self.current is not None:self.items.append(self.current);self.current=None

def test_compiled_importer_has_no_script_downloads():
 s=Scripts((R/'components/extractor.compiled.html').read_text())
 assert all('src' not in a for a,_ in s.items)
 assert any('tesseract.min.js' in a.get('data-nkpi-source','') for a,_ in s.items)

def test_inline_code_has_exact_csp_hashes():
 text=(R/'components/extractor.compiled.html').read_text()
 policy=re.search(r'script-src (.*?);',text,re.S).group(1)
 assert "'unsafe-inline'" not in policy
 for attrs,body in Scripts(text).items:
  if attrs.get('type')=='application/octet-stream':continue
  digest=base64.b64encode(hashlib.sha256(body.encode()).digest()).decode()
  assert "'sha256-"+digest+"'" in policy,attrs

def test_embedded_assets_are_the_original_bytes():
 items={a.get('id'):b for a,b in Scripts((R/'components/extractor.compiled.html').read_text()).items if a.get('id')}
 rel={'nkpi-worker':'vendor/tesseract-v7/worker.min.js','nkpi-core-portable':'vendor/tesseract-v7/tesseract-core-lstm.wasm.js','nkpi-core-simd':'vendor/tesseract-v7/tesseract-core-simd-lstm.wasm.js','nkpi-core-relaxed':'vendor/tesseract-v7/tesseract-core-relaxedsimd-lstm.wasm.js','nkpi-model-primary':'ocr_data/eng.traineddata','nkpi-model-secondary':'ocr_second/eng.traineddata'}
 for key,name in rel.items():assert gzip.decompress(base64.b64decode(items[key]))==(R/'components/extractor'/name).read_bytes()

def test_main_contains_complete_importer_and_no_import_url():
 text=(R/'components/index.html').read_text()
 items={a.get('id'):b for a,b in Scripts(text).items if a.get('id')}
 assert gzip.decompress(base64.b64decode(items['nkpi-extractor-document']))==(R/'components/extractor.compiled.html').read_bytes()
 assert not re.search(r'<iframe[^>]*\bsrc=',text)
 assert "window.NKPIExtractorMount(frame)" in (R/'components/app.js').read_text()

def test_new_component_identity_and_original_source():
 assert 'nkpi_oct27_reader_fluid_v921' in (R/'nkpi/component.py').read_text()
 assert '9.2.1-fluid-replay' in (R/'nkpi/service.py').read_text()
 manifest=json.loads((R/'docs/SOURCE_PROVENANCE.json').read_text())
 assert manifest['extractor_source']=='NKPI_v910_GitHub_Upload.zip'
 for path,sha in manifest['preserved'].items():
  if path in ['components/replay/gif_encoder.js','components/replay/replay.css']:continue # explicitly replaced replay code
  assert hashlib.sha256((R/path).read_bytes()).hexdigest()==sha,path

def test_failure_not_silently_accepted():
 guard=(R/'components/delivery/extractor_guard.js').read_text()
 assert 'Automatic extraction stopped:' in guard
 assert 'No measurements were read' in guard
 assert 'return legacyParseArchive(file,label)' in guard
 assert 'forceManualImport=true' not in guard

def test_transport_has_no_patient_uploads_or_persistent_results():
 for name in ['ocr_delivery.js','mount_extractor.js','extractor_guard.js']:
  text=(R/'components/delivery'/name).read_text()
  for api in ['XMLHttpRequest','localStorage','sessionStorage','indexedDB']:
   assert api not in text
  assert 'fetch(' not in text

def test_worker_cleanup_on_failure_and_unload():
 text=(R/'components/delivery/ocr_delivery.js').read_text()
 assert 'raw?.terminate()' in text
 assert "window.addEventListener('pagehide',dispose)" in text
 assert 'window.Worker=NativeWorker' in text
 assert "creation=original('eng',oem" in text

def test_fluid_replay_uses_separate_renderer_and_preserves_reader():
 record=json.loads((R/'docs/FLUID_REPLAY_PROVENANCE.json').read_text())
 assert record['extractor_files']==34
 assert record['delivery_adapter_files']==3
 for path,sha in record['preserved'].items():
  assert hashlib.sha256((R/path).read_bytes()).hexdigest()==sha,path
 text=(R/'components/replay/replay_view.js').read_text()
 assert 'NKPIFluidRenderer' in text
 assert 'requestAnimationFrame(tick)' in text
 assert 'cachedImageFrames:0' in text
 assert 'renderWithExistingViewer' not in text
