'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),F=require('../components/replay/fluid_renderer.js'),I=require('../components/cornea/integrated_model.js'),R=require('../components/cornea/continuous_review.js');
const X=require('../components/replay/replay_math.js');
const fixture=JSON.parse(fs.readFileSync(process.env.FLUID_FIXTURE||require('node:path').join(__dirname,'fixtures/fluid_pair.json'),'utf8'));
const p=fixture.sets.OD,first=R.build(I.fromReport(p[0]),p[0],fixture.results.OD),latest=R.build(I.fromReport(p[1]),p[1],fixture.results.OD),before=JSON.stringify(fixture);
let passed=0;function test(name,fn){fn();console.log('PASS '+name);passed++;}
const g=F.buildGeometry(first,latest,{rings:12,sectors:48});
test('Each frame is an arbitrary surface fraction, not one of 13 images',()=>{let unique=new Set();for(let i=0;i<300;i++)unique.add(F.pose([0,0,0],[0,0,1],i/299)[2]);assert.equal(unique.size,300);assert.equal(F.pose([1,2,3],[2,4,6],0)[2],3);assert.equal(F.pose([1,2,3],[2,4,6],1)[2],6);});
test('Midpoint and gain affect display differences only',()=>{assert.deepEqual(F.pose([1,2,3],[2,3,4],.5,1),[1.5,2.5,3.5]);assert.deepEqual(F.pose([1,2,3],[2,3,4],.5,5),[3.5,4.5,5.5]);});
test('Zero changes stay still at all magnifications',()=>{for(const t of [0,.1,.4,.75,1])assert.deepEqual(F.pose([2,3,4],[2,3,4],t,10),[2,3,4]);});
test('Unsupported vertices remain at baseline, including amplified mode',()=>assert.deepEqual(F.pose([1,2,3],[3,4,8],.9,10,false),[1,2,3]));
test('Time mapping is continuous and bounded with short endpoint dwells',()=>{assert.equal(F.phase(0),0);assert.equal(F.phase(.08),0);assert(Math.abs(F.phase(.5)-.5)<1e-14);assert.equal(F.phase(1),1);for(let i=0;i<1000;i++)assert(Math.abs(F.phase((i+1)/1000)-F.phase(i/1000))<.002);});
test('Both endpoint sample arrays are finite and never alias source values',()=>{assert.equal(g.vertexCount,g.p0.length);assert(g.p0.every(a=>a.every(Number.isFinite)));assert(g.p1.every(a=>a.every(Number.isFinite)));assert(g.indices.every(i=>i<g.vertexCount));const old=first.front(0,0)[2];g.p0[0][2]+=1;assert.equal(first.front(0,0)[2],old);g.p0[0][2]-=1;});
test('One fixed physical scale bounds both endpoints and magnified differences',()=>{const P=F.projection([g], 'oblique',510,360,5);for(let i=0;i<g.p0.length;i+=5){for(const t of [0,1]){const p=F.project(F.pose(g.p0[i],g.p1[i],t,5,g.support[i]===1),P);assert(p[0]>=0&&p[0]<=510&&p[1]>=0&&p[1]<=360);}}});
test('Equal physical x/y/z scale is independent of animation fraction',()=>{const P=F.projection([g], 'front',510,360);assert(Math.abs(F.project([1,0,0],P)[0]-F.project([0,0,0],P)[0]-P.scale)<1e-12);assert(Math.abs(F.project([0,0,0],P)[1]-F.project([0,1,0],P)[1]-P.scale)<1e-12);});
test('No patient geometry prevents a fabricated mesh',()=>assert.throws(()=>F.buildGeometry({...first,hasPatientGeometry:false},latest)));
test('Mismatched laterality and grids still prohibit replay interpolation',()=>{assert(!X.geometryCompatibility(first,{...latest,report:{...latest.report,eye:'OS'}}).ok);assert(!X.geometryCompatibility(first,{...latest,source:{...latest.source,axisX:[1,2]}}).ok);});
test('All scalar inputs and original source reports remain unchanged',()=>assert.equal(JSON.stringify(fixture),before));
console.log(passed+' fluid geometry tests passed');
