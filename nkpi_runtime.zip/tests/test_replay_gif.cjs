'use strict';
const assert=require('node:assert/strict'),G=require('../components/replay/gif_encoder.js');
function decode(bytes){let pos=0,width=9,next=258,table=[],prev=null,out=[];const read=()=>{let v=0;for(let i=0;i<width;i++){if(pos>=bytes.length*8)throw Error('Truncated LZW');v|=((bytes[pos>>3]>>(pos&7))&1)<<i;pos++;}return v;};
 while(true){let code=read();if(code===256){table=Array.from({length:256},(_,i)=>[i]);next=258;width=9;prev=null;continue;}if(code===257)break;const entry=table[code]||(code===next&&prev?[...prev,prev[0]]:null);assert(entry);out.push(...entry);if(prev){table[next++]=[...prev,entry[0]];if(next===(1<<width)&&width<12)width++;}prev=entry;}
 return Uint8Array.from(out);
}
(async()=>{
 let seed=9154;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed&255;};
 for(const len of [1,127,1000,20000]){const pixels=Uint8Array.from({length:len},random);assert.deepEqual(decode(G.lzw(pixels)),pixels);}
 const data=Uint8ClampedArray.from({length:64*48*4},(_,i)=>i%4===3?255:random()),frames=[{data},{data:Uint8ClampedArray.from(data,(x,i)=>i%4===3?255:255-x)}];
 const blob=await G.encode(frames,{width:64,height:48,delays:[100,100]}),bytes=new Uint8Array(await blob.arrayBuffer());assert.equal(new TextDecoder().decode(bytes.slice(0,6)),'GIF89a');assert.equal(bytes.at(-1),0x3b);assert.equal(blob.type,'image/gif');
 const a=new AbortController();a.abort();await assert.rejects(G.encode(frames,{width:64,height:48,signal:a.signal}),/canceled/);await assert.rejects(G.encode([],{width:64,height:48}));
 console.log('PASS GIF: exact independent LZW decode at four sizes; GIF89a file and trailer; cancellation; empty-input rejection.');
})().catch(e=>{console.error(e);process.exitCode=1;});
