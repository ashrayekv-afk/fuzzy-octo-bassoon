# NKPI 9.1.5.4 — replay with the earlier extractor restored

## Release scope

This release is based on `NKPI_v9152_OCR_Repair_GitHub.zip`, outer SHA-256
`98ca30e3d54a0c4c1d6e6301ea6c32794e0a373227d92663f4609c0ae86fcfc2`.
That is the version the user reported working before the extraction upgrade.
It is NOT based on the failing v9.1.5.3 scheduling experiment.

All 36 files below `components/extractor/`, including the generated importer HTML,
OCR loaders, models, workers and reading logic, are restored byte-for-byte. The
v9.1.5.3 extraction-flow, label-binding and scheduling modules are not included.
All 13 original cornea files and all three frozen model artifacts are unchanged.
Their hashes are recorded in `REPLAY_PRESERVED_HASHES.json`. Requirements are unchanged.
No additional OCR accuracy or speed improvement is claimed.

## New module

Corneal Progression Replay sits immediately below the existing bilateral 3D view.
The same verified source-binding rules gate both viewers. It uses two imported
visits, not a newly invented multi-visit history. It must be prepared explicitly,
after measurement verification and calculation; it starts no OCR jobs.

- Observed-visit mode alternates only between baseline and latest reconstructions.
- Smooth illustration linearly interpolates compatible display coordinates and
  colors within the observed interval. Every intermediate frame is labeled as an
  illustration. Intermediate numerical measurements are withheld. No extrapolation
  beyond either endpoint is permitted.
- Both eyes share a camera. Profile, front and natural-eye views are available.
  Color modes include natural eye, thickness and anterior/posterior curvature where
  definitions permit a shared endpoint scale. The baseline guide follows a
  source-supported central superior–inferior meridian in display coordinates.
- The actual pre-existing integrated renderer is reused in a separate private
  renderer instance. The main eye viewer and its input arrays are not modified.
  Its Canvas fallback also renders intermediate geometry; a GPU is not required.
- The playback panel shows actual elapsed days, observed C and Kmax endpoints and
  annualized descriptive rates. The accompanying table contains A, B, C, Kmax,
  BAD-D and ARTmax. Annualization is raw difference × 365.25 / elapsed days.
- GIF, still PNG and browser-supported video exports are created locally. GIF uses
  a bundled dependency-free GIF89a encoder with an adaptive palette and LZW.
  Video uses feature-detected MediaRecorder/captureStream; codec support varies.
  No new Python dependency, CDN, server export endpoint or OCR download is added.

## Interpretation and safety boundaries

Endpoint views are reconstructions, not photographs. Report-image reconstructions
and completed peripheral geometry retain all previous limitations. Matching grids
are a software compatibility check, not proof of anatomical registration. Changing
best-fit-sphere references may contribute to apparent motion. The interpolation
must not be interpreted as measured tissue displacement or a biological trajectory.

Two visits provide a descriptive interval rate, not acceleration, a statistical
confidence interval, a progression diagnosis, or a prediction of the next visit.
No repeatability threshold or treatment rule is added. Clinical interpretation must
consider scan quality, repeatability, lens conditions and treatment between visits.
An interval containing CXL is not an untreated natural-history trajectory.

C remains the verified scalar minimum for its visit, not necessarily a measurement
at the same x/y location at both visits. Neither C nor NKPI deforms a surface.
Missing spatial information is not manufactured from scalar measurements. Mixed
eye/visit associations, unmatched sources and stale results cannot enable replay.
Different spatial grids/source types disable smooth geometry for that eye. A pair
with no patient-supported geometry remains unavailable, even when scalars exist.

New-patient clear/source changes dispose playback, pending preparation, hidden
renderers, generated frames and export URLs. Export cancellation prevents late
saving. All exports retain the interpretation labels. They omit patient names,
exact dates and original report images, but still contain clinical measurements
and must be handled under approved privacy arrangements.
