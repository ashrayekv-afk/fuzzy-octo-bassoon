"""Native Streamlit recovery interface. Delegates all scoring to the unchanged service.

No raw-file uploader, no browser custom component, no alternate coefficients.
All fields begin empty. Edits invalidate results and the affected eye's confirmation.
"""
from __future__ import annotations

import base64
import json
from typing import Any
import streamlit as st
from .assessment import FEATURES
from .service import calculate

_PREFIX = "nkpi_recovery_"


def _key(eye: str, field: str) -> str:
    return f"{_PREFIX}{eye}_{field}"


def _invalidate(eye: str) -> None:
    st.session_state.pop(_PREFIX + "response", None)
    st.session_state.pop(_PREFIX + "snapshot", None)
    st.session_state[_key(eye, "verified")] = False


def _clear() -> None:
    for key in list(st.session_state):
        if key.startswith(_PREFIX):
            del st.session_state[key]


def _snapshot(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _eye_editor(eye: str) -> dict[str, Any] | None:
    st.subheader("Right eye · OD" if eye == "OD" else "Left eye · OS")
    enabled = st.checkbox("Include this eye", value=True, key=_key(eye, "enabled"),
                          on_change=_invalidate, args=(eye,))
    if not enabled:
        return None
    label = st.selectbox("Visits", ["Single visit", "Two visits"], key=_key(eye, "mode"),
                         on_change=_invalidate, args=(eye,))
    paired = label == "Two visits"
    age = st.number_input("Age at first / only scan", min_value=18.0, max_value=100.0,
                          value=None, step=0.1, key=_key(eye, "age"),
                          on_change=_invalidate, args=(eye,))
    days = None
    if paired:
        days = st.number_input("Days between scans", min_value=1, max_value=36525,
                               value=None, step=1, key=_key(eye, "interval_days"),
                               on_change=_invalidate, args=(eye,))
    visits = ("first", "latest") if paired else ("first",)
    values = {}
    columns = st.columns(len(visits))
    for column, visit in zip(columns, visits):
        with column:
            st.markdown("**Later visit**" if visit == "latest" else "**First visit**" if paired else "**Selected visit**")
            values[visit] = {}
            for spec in FEATURES:
                field = spec["key"]
                label = spec["label"] + (f" ({spec['unit']})" if spec["unit"] else "")
                values[visit][field] = st.number_input(
                    label, min_value=float(spec["low"]), max_value=float(spec["high"]),
                    value=None, step=float(10 ** -spec["decimals"]),
                    format=f"%.{spec['decimals']}f", key=_key(eye, f"{visit}_{field}"),
                    on_change=_invalidate, args=(eye,),
                )
    treatment_label = st.selectbox(
        "Treatment history (optional)", ["Unknown / not entered", "Untreated", "Prior CXL"],
        key=_key(eye, "treatment"), on_change=_invalidate, args=(eye,),
    )
    verified = st.checkbox(
        "I verified this eye, all measurements, and the visit order against the source.",
        key=_key(eye, "verified"),
    )
    return {
        "eye": eye, "mode": "longitudinal" if paired else "baseline", "age": age,
        "first": values["first"], "latest": values.get("latest"), "interval_days": days,
        "verified": verified, "treatment": {
            "Unknown / not entered": "unknown", "Untreated": "untreated", "Prior CXL": "treated"
        }[treatment_label],
        "scan_quality": {visit: "unknown" for visit in visits},
        "context": {}, "demo": False,
    }


def render_recovery(config: dict[str, Any]) -> None:
    st.title("NKPI · Basic calculator")
    st.info("Loading-recovery mode uses the same frozen NKPI models. Enter verified numeric measurements manually. The ZIP extractor and 3D viewer remain in Full interface.")
    st.caption("Research index, not a percentage probability or treatment recommendation. A and B are radii in mm, not ABCD stage numbers. Do not enter patient identifiers.")
    st.button("Next patient / clear", key=_PREFIX + "clear", on_click=_clear)
    eyes = []
    for eye, column in zip(("OD", "OS"), st.columns(2)):
        with column:
            case = _eye_editor(eye)
            if case is not None:
                eyes.append(case)
    payload = {"eyes": eyes}
    snapshot = _snapshot(payload)
    # Do not show a previous score beside edited or unconfirmed measurements.
    if st.session_state.get(_PREFIX + "snapshot") != snapshot:
        st.session_state.pop(_PREFIX + "response", None)
        st.session_state.pop(_PREFIX + "snapshot", None)
    if st.button("Calculate NKPI now", type="primary", key=_PREFIX + "calculate", disabled=not eyes):
        try:
            result = calculate(payload)
        except (ValueError, TypeError, KeyError):
            st.error("Input verification failed. Check the values and confirmation. No score was substituted.")
        except Exception:
            st.error("Calculation did not complete. Restore the matching release package. No fallback score was used.")
        else:
            st.session_state[_PREFIX + "response"] = result
            st.session_state[_PREFIX + "snapshot"] = snapshot
    result = st.session_state.get(_PREFIX + "response")
    if result and st.session_state.get(_PREFIX + "snapshot") == snapshot:
        for eye, column in zip(("OD", "OS"), st.columns(2)):
            assessment = result["eyes"].get(eye)
            if assessment is None:
                continue
            with column:
                st.subheader(f"{eye} result")
                for message in assessment.get("errors", []) + assessment.get("holds", []):
                    st.error(message)
                if assessment.get("prediction"):
                    st.metric("NKPI", f"{assessment['prediction']['nkpi']:.1f} / 100")
                    with st.expander("Verified inputs and ranked score impact"):
                        st.dataframe(assessment["measurements"], hide_index=True, use_container_width=True)
                        st.dataframe(assessment["impact_audit"]["rows"], hide_index=True, use_container_width=True)
                    pdf = assessment.get("pdf_base64")
                    if pdf:
                        st.download_button("Download one-page PDF", data=base64.b64decode(pdf, validate=True),
                                           file_name=f"NKPI_{eye}_report.pdf", mime="application/pdf",
                                           key=_PREFIX + eye + "_pdf")
                else:
                    st.info("No NKPI score was calculated for this eye.")
                with st.expander("Model notes and limitations", expanded=False):
                    for message in assessment.get("warnings", []):
                        st.warning(message)
        clean = json.loads(json.dumps(result))
        for assessment in clean["eyes"].values():
            assessment.pop("pdf_base64", None)
        st.download_button("Download audited numeric results", data=json.dumps(clean, indent=2, allow_nan=False),
                           file_name="NKPI_audited_numeric_results.json", mime="application/json",
                           key=_PREFIX + "json")
    st.caption(f"Interface {config['ui_version']} · Frozen model {config['version']} · Clear after every patient.")
