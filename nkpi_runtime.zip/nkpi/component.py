"""Register from an importable module, independent of the ZIP launcher's __main__."""
from pathlib import Path
import streamlit.components.v1 as components

COMPONENT_NAME = "nkpi_oct27_reader_fluid_v921"

def render_workspace(**kwargs):
    # Register within the active ScriptRunContext on every Streamlit rerun.
    # Do not cache the declaration across sessions or depend on the working directory.
    frontend = (Path(__file__).resolve().parents[1] / "components").resolve()
    if not (frontend / "index.html").is_file():
        raise FileNotFoundError("The packaged NKPI frontend is missing.")
    workspace = components.declare_component(COMPONENT_NAME, path=str(frontend))
    return workspace(**kwargs)
